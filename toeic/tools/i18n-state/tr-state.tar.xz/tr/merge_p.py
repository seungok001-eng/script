# 새 실전(p) 번역 조각(out/<L>/p-31..36.json, en 은 _prefill_gram.json 포함)을 앱 파일 data/i18n/<L>.json 의 p 에 더한다 (기존 ui·labels 는 그대로)
import json, glob, os, sys
I = '/home/user/script/toeic/data/i18n'; H = os.path.dirname(os.path.abspath(__file__))
src = json.load(open(f'{I}/src.ko.json'))
for L in sys.argv[1:]:
    tr = {}
    for f in [f'{H}/out/{L}/p-{i}.json' for i in range(31, 60)] + ([f'{H}/out/en/_prefill_gram.json', f'{H}/out/en/_prefill_rc.json'] if L == 'en' else []):
        if os.path.exists(f): tr.update(json.load(open(f)))
    p = f'{I}/{L}.json'; d = json.load(open(p)); n = 0
    for k, v in tr.items():
        if k in src['p']: d['p'][k] = [src['p'][k], v]; n += 1
    json.dump(d, open(p, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    print(L, 'added', n, 'p total', len(d['p']), '/', len(src['p']))
