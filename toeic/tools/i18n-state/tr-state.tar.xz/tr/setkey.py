"""setkey: 번역 하나를 앱 파일(data/i18n/<L>.json)과 작업 파일(out/<L>*/…)에 같이 고친다 — 나중에 merge_p 를 다시 돌려도 되돌아가지 않게."""
import json, glob, os
I = '/home/user/script/toeic/data/i18n'; H = os.path.dirname(os.path.abspath(__file__))
_cache = {}
def app(L):
    if L not in _cache: _cache[L] = json.load(open(f'{I}/{L}.json'))
    return _cache[L]
def set_p(L, key, val):
    d = app(L); assert key in d['p'], (L, key); d['p'][key] = [d['p'][key][0], val]
    for f in glob.glob(f'{H}/out/{L}/*.json'):
        t = json.load(open(f))
        if isinstance(t, dict) and key in t: t[key] = val; json.dump(t, open(f, 'w'), ensure_ascii=False, indent=1)
def set_ui(L, key, val):
    d = app(L); hit = 0
    for sec in ('ui', 'labels'):
        if key in d.get(sec, {}): d[sec][key] = val; hit = 1
    assert hit, (L, key)
    for f in glob.glob(f'{H}/out/{L}-ui*.json'):
        t = json.load(open(f))
        if key in t: t[key] = val; json.dump(t, open(f, 'w'), ensure_ascii=False, indent=1)
def save():
    for L, d in _cache.items(): open(f'{I}/{L}.json', 'w').write(json.dumps(d, ensure_ascii=False, separators=(',', ':')))
