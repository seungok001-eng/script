# 번역 조각(out/<lang>-ui.json, -labels.json, out/<lang>/*.json)을 앱 형식 data/i18n/<lang>.json 으로 합친다
# python3 assemble.py <lang> [<lang> ...]   → 키 수·누락 출력. 원문이 바뀐 키는 [옛 원문, 번역] 그대로 두면 build 가 '다시 번역'으로 센다
import json, glob, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
I18N = '/home/user/script/toeic/data/i18n'
NAMES = {'en': 'English', 'ja': '日本語', 'vi': 'Tiếng Việt', 'zh-TW': '繁體中文', 'es': 'Español', 'fr': 'Français'}
src = json.load(open(f'{I18N}/src.ko.json', encoding='utf-8'))
for lang in sys.argv[1:]:
    ui = json.load(open(f'{HERE}/out/{lang}-ui.json', encoding='utf-8')) if os.path.exists(f'{HERE}/out/{lang}-ui.json') else {}
    labels = json.load(open(f'{HERE}/out/{lang}-labels.json', encoding='utf-8')) if os.path.exists(f'{HERE}/out/{lang}-labels.json') else {}
    tr = {}
    for f in sorted(glob.glob(f'{HERE}/out/{lang}/*.json')):
        tr.update(json.load(open(f, encoding='utf-8')))
    out = {'lang': lang, 'name': NAMES[lang], 'ui': {k: v for k, v in ui.items() if k in src['ui']},
           'labels': {k: v for k, v in labels.items() if k in src['labels']},
           'd': {k: [ko, tr[k]] for k, ko in src['d'].items() if k in tr},
           'p': {k: [ko, tr[k]] for k, ko in src['p'].items() if k in tr}}
    json.dump(out, open(f'{I18N}/{lang}.json', 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
    print(lang, 'ui', len(out['ui']), '/', len(src['ui']), 'labels', len(out['labels']), '/', len(src['labels']),
          'd', len(out['d']), '/', len(src['d']), 'p', len(out['p']), '/', len(src['p']))
