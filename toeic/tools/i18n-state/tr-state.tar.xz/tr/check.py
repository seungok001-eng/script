# 번역 결과 검사: 키 누락·한글 잔존·자리표시자·HTML 태그·(A)~(D)·인용된 영어 구절 보존
# python3 check.py <input chunk(.json: list of records | ui source)> <output.json> <lang>
import json, re, sys
src_f, out_f, lang = sys.argv[1:4]
src = json.load(open(src_f, encoding='utf-8'))
out = json.load(open(out_f, encoding='utf-8'))
if isinstance(src, list):
    keys = {}
    for r in src: keys.update(r['keys'])
else:
    keys = {k: (v['ko'] if isinstance(v, dict) else v) for k, v in src.items()}
H = re.compile(r'[가-힣ㄱ-ㆎ]')
errs = []
miss = [k for k in keys if k not in out]
extra = [k for k in out if k not in keys]
if miss: errs.append(f'누락 {len(miss)}: {miss[:5]}')
if extra: errs.append(f'남는 키 {len(extra)}: {extra[:5]}')
def eng_frags(s):
    # 한국어 문장 속 영어 구절(3단어 이상 연속) — 번역에도 그대로 있어야 한다
    return [m.group(0).strip() for m in re.finditer(r"[A-Za-z][A-Za-z0-9'’,.\-]*(?:\s+[A-Za-z0-9'’,.\-]+){2,}", s)]
for k, ko in keys.items():
    t = out.get(k)
    if t is None: continue
    if not isinstance(t, str) or not t.strip(): errs.append(f'빈 번역 {k}'); continue
    if H.search(t): errs.append(f'한글 남음 {k}: {t[:60]}')
    if sorted(re.findall(r'\{\d+\}', ko)) != sorted(re.findall(r'\{\d+\}', t)): errs.append(f'자리표시자 {k}')
    # 태그 구조(이름·순서·속성 이름)만 비교 — 속성 값(aria-label 등)은 번역 대상
    tagsig = lambda s: [(m.group(1), tuple(re.findall(r'\s([a-z-]+)=', m.group(2)))) for m in re.finditer(r'<(/?[a-z][a-z0-9]*)([^>]*)>', s)]
    if tagsig(ko) != tagsig(t): errs.append(f'HTML 태그 {k}')
    for av in re.findall(r'="([^"]*)"', t):
        if H.search(av): errs.append(f'속성값 한글 {k}')
    for L in re.findall(r'\(([A-D])\)', ko):
        if f'({L})' not in t: errs.append(f'보기 글자 ({L}) 빠짐 {k}'); break
    # 영어 구절: 문장부호(쉼표·마침표·따옴표)는 언어에 맞게 바뀌어도 되고, 영어 단어는 같은 순서로 남아야 한다
    tw = [w.lower() for w in re.findall(r"[A-Za-z0-9]+(?:'[A-Za-z]+)?", t)]  # 문장 첫머리 대문자화는 허용
    def in_order(words):
        i = 0
        for w in tw:
            if i < len(words) and w == words[i]: i += 1
        return i == len(words)
    for fr in eng_frags(ko):
        words = [w.lower() for w in re.findall(r"[A-Za-z0-9]+(?:'[A-Za-z]+)?", fr) if re.search(r"[A-Za-z]", w)]  # 숫자는 언어마다 표기가 달라도 됨
        if len(words) >= 3 and not in_order(words):
            errs.append(f'영어 구절 바뀜 {k}: "{fr[:50]}"'); break
    lim = max(40, len(ko) * 3) if lang in ('ja', 'zh-TW') else max(70, len(ko) * 6)
    if len(t) > lim: errs.append(f'너무 김 {k}')
if errs:
    print(f'문제 {len(errs)}개'); print('\n'.join(errs[:40])); sys.exit(1)
print(f'OK {len(keys)}개')
