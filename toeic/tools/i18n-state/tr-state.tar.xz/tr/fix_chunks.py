# 새 실전 키(어휘 vocab5 · Part 6 · Part 7 보강분) → src/p-4N.json, 영어는 src-en/ (지문 해석·질문 번역은 영어 원문으로 미리 채움)
import json, re
T = '/home/user/script/toeic'
src = json.load(open(f'{T}/data/i18n/src.ko.json')); en = json.load(open(f'{T}/data/i18n/en.json'))
D = {'vocab5': {t['id']: t for t in json.load(open(f'{T}/data/practice/vocab5.json'))},
     'p6': {x['id']: x for x in json.load(open(f'{T}/data/practice/p6.json'))},
     'p7': {x['id']: x for x in json.load(open(f'{T}/data/practice/p7.json'))}}
H = re.compile('[가-힣]')
def clean(x):
    if isinstance(x, str): return '@' if H.search(x) else x
    if isinstance(x, list): return [clean(v) for v in x]
    if isinstance(x, dict): return {k: clean(v) for k, v in x.items() if k not in ('lv', 'mock', 'ev')}
    return x
miss = [k for k in src['p'] if k.split('/')[0] in D and (k not in en['p'] or en['p'][k][0] != src['p'][k])]
recs, pre = {}, {}
for k in miss:
    s = k.split('/'); obj = D[s[0]][s[1][1:]]
    if s[0] == 'vocab5':
        if s[2] in ('qs', 'lesson'):
            root = '/'.join(s[:4]); ctx = clean(next(q for q in obj['qs'] if q['id'] == s[3][1:]) if s[2] == 'qs' else obj['lesson'][int(s[3])])
        else: root = '/'.join(s[:3]); ctx = {'topic': obj['title'] and '@', 'colloc_en': [c['en'] for c in obj.get('colloc', [])]} if s[2] == 'colloc' else {'note': 'trap = common mistake paragraph for this vocabulary type'}
        if s[2] == 'lesson' and s[-1] == 'ko' and s[-3] == 'ex': pre[k] = obj['lesson'][int(s[3])]['ex'][int(s[5])]['en'].replace('*', '')
    else:
        root = '/'.join(s[:2]); ctx = clean(obj)
        if s[0] == 'p6' and s[2] == 'ko': pre[k] = obj['paras'][int(s[3])]
        if s[0] == 'p7' and s[2] == 'docs' and s[4] == 'ko': pre[k] = obj['docs'][int(s[3])]['paras'][int(s[5])]
        if s[0] == 'p7' and s[2] == 'qs' and s[-1] == 'qko': pre[k] = obj['qs'][int(s[3])]['q']
    recs.setdefault(root, {'root': root, 'ctx': ctx, 'keys': {}})['keys'][k] = src['p'][k]
def chunk(rs, lim):
    out, cur, size = [], [], 0
    for r in rs:
        sz = sum(len(v) for v in r['keys'].values())
        if size + sz > lim and cur: out.append(cur); cur, size = [], 0
        cur.append(r); size += sz
    if cur: out.append(cur)
    return out
allc = chunk(list(recs.values()), 34000)
for i, c in enumerate(allc):
    n = 53 + i
    json.dump(c, open(f'src/p-{n}.json', 'w'), ensure_ascii=False, indent=1)
    ce = [{**r, 'keys': {k: v for k, v in r['keys'].items() if k not in pre}} for r in c]
    json.dump([r for r in ce if r['keys']], open(f'src-en/p-{n}.json', 'w'), ensure_ascii=False, indent=1)
assert not pre, pre
print(len(miss), 'keys', len(recs), 'records', len(allc), 'chunks p-41..', 40 + len(allc), 'en prefill', len(pre))
