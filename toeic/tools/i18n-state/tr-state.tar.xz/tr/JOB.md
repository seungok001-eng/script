# One translation job = one chunk C (d-NN or p-NN) into one language L
Work dir: /tmp/claude-0/-home-user-script/daeb160e-7d1b-5b97-88f4-a9d67a2fe616/scratchpad/tr/

1. Read TRANSLATE.md (strict rules) and out/L-glossary.md (use its terms).
2. If an earlier output of the same language exists, match its style: out/L/d-01.json for word data (d-*), out/L/p-01.json for practice/mock data (p-*). (If those don't exist yet, set the style by TRANSLATE.md.)
3. Input src/C.json = list of records {root, ctx, keys}; ctx is the English context (Korean values shown as "@"). If a passage lacks English in ctx, find exact names in practice-all.json.
4. Write out/L/C.json = flat {key: translation} for EVERY key, using Python (several passes fine); keep work files in work/L-C/.
5. Run `python3 check.py src/C.json out/L/C.json L` until it prints OK.
6. Review ~40 random items against ctx as a strict native reviewer; fix anything wrong or unnatural; re-run the checker.

House style decisions (all languages):
- People's names: always the ENGLISH spelling from ctx, never transliterated (no katakana/hanzi/phonetic respelling). Use the honorific that is natural in L: English title (Ms. Patel, Dr. Cho) or L's own (ja: Patelさん / Daniel Ruizさん / Haddad様 in letters; es: la Sra. Patel / la Dra. Kim; fr: Mme Patel). vi: ALWAYS the Vietnamese form, never "Ms./Mr." next to Vietnamese pronouns — Mr. Patel → ông Patel, Ms./Mrs. Patel → bà Patel (cô Patel for a young woman in casual dialogue), Dr. Kim → bác sĩ Kim (medical) / tiến sĩ Kim (otherwise); first names alone stay as they are (Daniel, anh Daniel / chị Maria where Vietnamese needs a pronoun). Be consistent within a record.
- Well-known city/country names may use the standard target-language spelling.
- Example-sentence translations: plain/neutral register; customer-facing lines (notices, ads, service messages) may use the polite register natural in L.
- Korean-only teaching points (Korean pronunciation, Konglish) → rewrite for an L speaker, using IPA from ctx if needed.

Never modify anything under /home/user/script. Final answer: ONE short paragraph — key count, checker result, real doubts only.

- Keep every helper script and batch file inside your own work/<L>-<C>/ folder. Never create or overwrite files directly in work/ or anywhere shared.
