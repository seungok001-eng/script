import json, re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ui = json.load(open(f'{base}/ui.json', encoding='utf-8'))
keys = list(ui.keys())
import ui_a, ui_b
U = {}; RP = {}
for m in (ui_a, ui_b):
    for i in m.U:
        assert i not in U and i not in RP, i
        U[i] = m.U[i]
    for i in m.RP:
        assert i not in U and i not in RP, i
        RP[i] = m.RP[i]
missing = [i for i in range(len(keys)) if i not in U and i not in RP]
assert not missing, missing
out = {}
errs = []
for i, k in enumerate(keys):
    if i in U:
        t = U[i]
    else:
        t = k
        for a, b in RP[i]:
            if a not in t:
                errs.append(f'{i}: fragment not found: {a[:60]}')
            t = t.replace(a, b)
    out[k] = t
if errs:
    print('\n'.join(errs)); sys.exit(1)

H = re.compile(r'[가-힣]')
def typo(s):
    # split into tags and text; only touch text parts (and attribute values of aria-label/title/placeholder/alt)
    parts = re.split(r'(<[^>]+>)', s)
    res = []
    for p in parts:
        if p.startswith('<') and p.endswith('>'):
            p = re.sub(r'((?:aria-label|title|placeholder|alt)=")([^"]*)(")', lambda m: m.group(1) + fix(m.group(2)) + m.group(3), p)
            res.append(p)
        else:
            res.append(fix(p))
    return ''.join(res)
def fix(t):
    t = re.sub(r' :', '\u00a0:', t)
    t = re.sub(r' ([;!?])', '\u202f\\1', t)
    t = t.replace('« ', '«\u00a0').replace(' »', '\u00a0»')
    t = re.sub(r' %', '\u00a0%', t)
    t = re.sub(r'(\d|\}) (min|s|h|j|pts)\b', '\\1\u00a0\\2', t)
    t = re.sub(r'([nN]°) ', '\\1\u00a0', t)
    t = re.sub(r'\b(J-)', '\\1', t)
    return t
out = {k: typo(v) for k, v in out.items()}
os.makedirs(f'{base}/out', exist_ok=True)
json.dump(out, open(f'{base}/out/fr-ui.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)

labels = json.load(open(f'{base}/labels.json', encoding='utf-8'))
lk = list(labels.keys())
lt = [l.rstrip('\n') for l in open(f'{base}/fr_work/labels_fr.txt', encoding='utf-8')]
assert len(lt) == len(lk), (len(lt), len(lk))
lout = {k: fix(v) for k, v in zip(lk, lt)}
json.dump(lout, open(f'{base}/out/fr-labels.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('written', len(out), len(lout))
