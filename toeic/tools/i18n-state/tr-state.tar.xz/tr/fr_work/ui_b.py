# French UI translations, part B (indices 330-716)
U = {}
RP = {}
def S(i, t): U[i] = t
def R(i, pairs): RP[i] = pairs

S(330, "Les nouveaux mots étudiés apparaîtront ici")
S(331, "Parmi les {0} mots vus")
S(332, "Étudiez d'abord quelques mots")
R(333, [("<h2>전체 범위 테스트</h2>", "<h2>Test sur tout le programme</h2>"),
        ('<div class="tt">배운 단어 랜덤 30문제</div>', '<div class="tt">30 questions au hasard sur vos mots</div>')])
R(334, [("<b>복습 탭</b> 외운 단어는 1·3·7·14·30일 간격으로 이곳에 다시 나와요. 매일 <b>복습 예정</b>을 비우는 게 오래 기억하는 핵심이에요. 틀린 단어는 오답노트에 따로 모여요.",
         "<b>Onglet Révisions</b> Les mots appris reviennent ici après 1, 3, 7, 14 et 30 jours. Vider chaque jour la liste <b>À réviser</b> est la clé pour retenir durablement. Les mots ratés vont dans le carnet d'erreurs.")])
S(335, "Mots importants")
S(336, "Test aléatoire")
R(337, [('<b>Part 2 요령</b> 질문에 직접 답하지 않는 <b>우회 응답</b>이 정답인 경우가 많아요. "글쎄요", "~에게 물어보세요", "아직 정해지지 않았어요" 같은 답을 놓치지 마세요. 질문의 단어를 그대로 반복하는 보기는 함정일 때가 많아요.',
         "<b>Astuce Part 2</b> La bonne réponse est souvent une <b>réponse indirecte</b>, qui ne répond pas directement à la question : « I'm not sure », « Ask ~ », « It hasn't been decided yet »… Ne les ratez pas. Une option qui répète un mot de la question est souvent un piège.")])
R(338, [("<b>Part 3 요령</b> 대화를 듣기 전에 문제를 먼저 읽어 두세요. 정답은 대화의 표현을 <b>다른 말로 바꿔</b> 나오고, 마지막 부분의 '다음에 할 일'·'요청 사항'이 자주 출제돼요.",
         "<b>Astuce Part 3</b> Lisez les questions avant d'écouter la conversation. La bonne réponse <b>reformule</b> les mots entendus, et les questions sur « la suite » ou « la demande » en fin de dialogue sont fréquentes.")])
R(339, [("<b>Part 4 요령</b> 첫 문장에서 <b>담화 종류</b>(안내·광고·메시지·방송)와 장소를 잡으면 절반은 풀려요. ",
         "<b>Astuce Part 4</b> Identifiez dès la première phrase le <b>type d'exposé</b> (annonce, publicité, message, émission) et le lieu : c'est la moitié du travail. "),
        ("<span class=\"en\">Please ~ / Make sure ~</span> 뒤의 요청 사항을 놓치지 마세요.",
         "Repérez bien la demande qui suit <span class=\"en\">Please ~ / Make sure ~</span>.")])
S(340, "Part 1 Expressions photo")
S(341, "{0} phrases qui tombent telles quelles en description de photos")
R(342, [("<b>핵심 함정</b> 사람이 없는 사진에서 ", "<b>Piège clé</b> Sur une photo sans personne, "),
        ('<span class="en">is being + p.p.</span>(지금 ~되는 중)는 대부분 오답! 사물의 상태는 ',
         '<span class="en">is being + p.p.</span> (action en cours) est presque toujours faux ! L\'état d\'un objet s\'exprime avec '),
        ('<span class="en">is/are + p.p.</span>, <span class="en">has been + p.p.</span>로 말해요.',
         '<span class="en">is/are + p.p.</span> ou <span class="en">has been + p.p.</span>.')])
S(343, "Expressions LC fréquentes")
S(344, "{0} expressions fréquentes des Part 2 à 4 (conversations, exposés)")
S(345, "Raté")
S(346, "Réussi")
R(347, [('aria-label="듣기"', 'aria-label="Écouter"')])
S(348, " · {0} expressions ratées")
S(349, "Expressions faites {0}/{1} · réussite {2} %{3}")
S(350, "Choisissez une Part ou un thème ci-dessous pour un quiz ciblé")
R(351, [("<b>Part 2 응답 고르기</b>", "<b>Part 2 Choisir la réponse</b>"),
        ("<span>질문 듣고 3개 중 고르기 · {2}문항</span>", "<span>Écoutez, choisissez parmi 3 · {2} questions</span>"),
        ("<b>듣고 해석 고르기</b>", "<b>Écouter et traduire</b>"),
        ("<span>Part 3·4 문장 · {5}문항</span>", "<span>Phrases des Part 3·4 · {5} questions</span>")])
S(352, "Masquer la traduction")
S(353, "Afficher la traduction")
R(354, [("틀린 표현 {1}", "Ratées {1}")])
R(355, [("더 보기 ({0}개 남음)", "Voir plus ({0} restantes)")])
R(356, [("{3}이 목록 연속 듣기", "{3}Écouter toute la liste"), ('data-g="all">전체 {6}', 'data-g="all">Toutes {6}')])
S(357, "Aucune expression pour créer des questions")
S(358, "Part 2 Choisir la réponse")
S(359, "Écouter et traduire")
R(360, [("질문과 보기 (A)(B)(C)를 듣고 알맞은 응답을 고르세요", "Écoutez la question et les options (A)(B)(C), puis choisissez la bonne réponse")])
R(361, [('aria-label="다시 듣기"', 'aria-label="Réécouter"')])
R(362, [("문장을 듣고 알맞은 해석을 고르세요", "Écoutez la phrase et choisissez la bonne traduction")])
R(363, [("보기 {0}", "Option {0}")])
R(364, [('aria-label="보기 {1} 듣기"', 'aria-label="Écouter l\'option {1}"')])
S(365, "Part 2 · Quelle est la bonne réponse ?")
S(366, "Part {0} · Que signifie cette phrase ?")
S(367, "Écouter sans transcription")
S(368, "Avec la transcription")
R(369, [("<kbd>{6}</kbd> 선택 · <kbd>R</kbd> 다시 듣기 · <kbd>Enter</kbd> 다음", "<kbd>{6}</kbd> choisir · <kbd>R</kbd> réécouter · <kbd>Enter</kbd> suivant")])
R(370, [("<b>Part 2</b> 질문 다음에 (A)(B)(C) 세 응답이 차례로 나와요. 질문에 바로 답하지 않고 <b>돌려 말하는 응답</b>('확인해 볼게요', '아직 몰라요')이 정답인 경우가 많아요.",
         "<b>Part 2</b> Après la question, trois réponses (A)(B)(C) sont lues. La bonne réponse est souvent une <b>réponse indirecte</b> (« Let me check », « I don't know yet ») plutôt qu'une réponse directe.")])
S(371, "Facile")
S(372, "Moyen")
S(373, "Difficile")
S(374, "Exercices")
R(375, [("<b>문제를 불러오는 중…</b>", "<b>Chargement des questions…</b>")])
R(376, [("<b>문제를 불러오지 못했어요</b>앱을 다시 열어 주세요", "<b>Impossible de charger les questions</b>Rouvrez l'application")])
S(377, "Réponse")
S(378, "Réponse : {0} (sans réponse)")
R(379, [("{1}근거 위치 보기", "{1}Voir l'indice")])
S(380, "F2")
S(381, "H2")
S(382, " n° {0}")
R(383, [('alt="Part 1 사진{1}"', 'alt="Photo Part 1{1}"')])
S(384, "N° {0} · ")
R(385, [('aria-label="재생"', 'aria-label="Lecture"'), ("{2}사진을 가장 잘 묘사한 문장은?", "{2}Quelle phrase décrit le mieux la photo ?"),
        ("보기 4문장", "4 options")])
R(386, [("보기 {4}", "Option {4}")])
R(387, [("(A)~(D) 네 문장을 듣고 사진과 맞는 것을 고르세요. 문장은 채점 뒤에 보여 드려요.",
         "Écoutez les quatre phrases (A)~(D) et choisissez celle qui correspond à la photo. Le texte s'affiche après la correction.")])
R(388, [("함정: {0}", "Piège : {0}")])
R(389, [("문장을 누르면 그 문장만 다시 들어요", "Touchez une phrase pour la réécouter")])
S(390, " · 3 interlocuteurs")
S(391, "Exposé")
R(392, [("{0}따라 말하기", "{0}Répéter")])
R(393, [('aria-label="재생"', 'aria-label="Lecture"'), ("<b>{2} 듣기</b>", "<b>Écoute · {2}</b>"), ("{4}문장", "{4} phrases")])
R(394, [("<h2>스크립트</h2>", "<h2>Transcription</h2>"),
        ("문장을 누르면 그 문장부터 다시 들어요 · 근거 위치 보기를 누르면 정답 근거 문장이 표시돼요",
         "Touchez une phrase pour reprendre l'écoute à cet endroit · « Voir l'indice » surligne la phrase qui justifie la réponse")])
S(395, "Quelle phrase complète le texte ?")
S(396, "Document {0} · ")
R(397, [("닫기", "Fermer")])
S(398, "Part {0} à 7 · Demi-tests blancs · Score estimé")
R(399, [("<small>점</small>", "<small> pts</small>"), ("최근 문제", "questions récentes")])
R(400, [("<small>점</small>", "<small> pts</small>"), ("<b>진단</b>20문제 기준", "<b>Test</b>sur 20 questions"),
        ("LC·RC 각 30문제를 풀면 더 정확한 예상 점수로 바뀌어요 (지금 {3}/30 · {4}/30)",
         "Faites 30 questions en LC et en RC pour un score plus précis (actuellement {3}/30 · {4}/30)")])
R(401, [("LC·RC 각 30문제를 풀면<br>예상 점수를 알려 드려요", "Faites 30 questions en LC et en RC<br>pour obtenir un score estimé")])
S(402, "{0} complets · ")
S(403, "Part 1 Photographies")
S(404, "{0} / {1} questions")
S(405, "Part 2 Questions-réponses")
S(406, "Écoute, 3 options · {0} questions")
S(407, "{0} / {1} séries")
S(408, "Part 4 Exposés")
S(409, "Dictée")
S(410, "Écouter, écrire, répéter")
S(411, "Part 5 Grammaire")
S(412, "{0} thèmes · {1}/{2} questions")
S(413, "Exercices avec vos mots")
S(414, "Part 6 Textes à compléter")
S(415, "{0} / {1} textes")
S(416, "{0} expressions des Part 2 à 4")
S(417, "{0} phrases clés de description")
S(418, "Mots à ne pas confondre")
S(419, "{0} séries de mots proches")
S(420, "Paraphrases en contexte")
S(421, "Mode écoute")
S(422, "Lecture auto pendant vos trajets")
R(423, [("연습", "Travailler")])
R(424, [("{2}/{3} 정답", "{2}/{3} justes")])
R(425, [("<b>아직 데이터가 부족해요</b>문제를 풀면 유형별 정답률과 약점을 알려 드려요",
         "<b>Pas encore assez de données</b>Faites des exercices pour voir votre réussite par type et vos points faibles")])
R(426, [("예상 점수 (추정)", "Score estimé (approx.)"), ("{2}모의고사 ({3}하프 {4}회)", "{2}Tests blancs ({3}{4} demi-tests)"),
        ("<h2>LC 듣기</h2>", "<h2>LC · Compréhension orale</h2>"), ("<h2>RC 읽기</h2>", "<h2>RC · Compréhension écrite</h2>"),
        ("<h2>표현 · 특훈</h2>", "<h2>Expressions · Entraînement ciblé</h2>"), ("<h2>약점 분석</h2>", "<h2>Points faibles</h2>"),
        ("5문제 이상 푼 유형", "types avec 5 questions ou plus"),
        ("모든 문제는 이 앱에서 새로 만든 실전형 문제입니다(기출 문제 아님). 예상 점수는 최근 정답률로 계산한 참고용 추정치예요.",
         "Toutes les questions sont des exercices inédits de type TOEIC, créés pour cette app (pas des questions officielles). Le score estimé est indicatif et repose sur votre réussite récente.")])
R(427, [("<b>실전 탭</b> Part별 문제와 하프 모의고사가 모여 있어요. LC·RC를 각각 30문제 이상 풀면 <b>예상 점수</b>를 알려 드려요. 처음이라면 Part 2 응답이나 Part 5 문법부터 가볍게 시작해 보세요.",
         "<b>Onglet Pratique</b> Exercices par Part et demi-tests blancs. Faites au moins 30 questions en LC et en RC pour obtenir un <b>score estimé</b>. Pour débuter, essayez la Part 2 ou la grammaire de la Part 5.")])
S(428, "Aucune série à travailler")
S(429, "{0} · focus : {1}")
S(430, "Document simple")
S(431, "Documents doubles")
S(432, "Documents triples")
S(433, "Regardez d'abord la photo et anticipez les actions, l'état et la position des objets. Sur une photo sans personne, 'is being p.p.' (action en cours) est presque toujours faux.")
S(434, "Lisez les questions avant d'écouter. Après la correction, la phrase-indice est montrée dans la transcription.")
S(435, "Repérez dès la première phrase le type d'exposé et le lieu. Après la correction, vous pouvez réécouter et répéter chaque phrase.")
S(436, "Ne regardez pas seulement autour du blanc : tenez compte du contexte (temps, enchaînement). Pour l'insertion de phrase, tout repose sur le lien avec les phrases voisines.")
S(437, "Lisez les questions, puis cherchez l'indice dans le texte. Après la correction, il est surligné dans le texte.")
S(438, " · {0} questions")
S(439, "{0} questions · faites : {1}")
S(440, " textes")
S(441, " séries")
S(442, "{0}{1} · faites : {2}")
S(443, "6 questions")
S(444, "2 séries")
S(445, "3 séries")
S(446, "2 min par texte")
S(447, "1 min par question")
R(448, [("{1}실전 시간으로 풀기 · {2}{3}", "{1}Chronométré · {2}{3}")])
S(449, "Non faites")
S(450, "Ratées")
R(451, [("<b>조건에 맞는 세트가 없어요</b>", "<b>Aucune série ne correspond</b>")])
R(452, [("{4}{5} 이어 풀기", "{4}Continuer : {5}")])
S(453, "{0} · chronométré")
S(454, "Aucune série à faire")
S(455, " · temps dépassé")
S(456, "Temps : {1} / {0}{2}")
R(457, [("{0}지문", "{0}Texte"), ("{1}문제", "{1}Questions")])
S(458, " questions")
S(459, "Série suivante")
S(460, "Corriger")
S(461, "{0} sans réponse")
R(462, [("<b>Part 1</b> 사진을 먼저 보고 사람의 동작과 사물의 위치를 떠올린 뒤 네 문장을 들으세요. 문장은 채점한 뒤에 보여 드려요.",
         "<b>Part 1</b> Regardez d'abord la photo, anticipez les actions des personnes et la position des objets, puis écoutez les quatre phrases. Le texte s'affiche après la correction.")])
R(463, [("<b>Part 3·4 요령</b> 음성이 나오기 전에 <b>문제를 먼저 읽어 두세요</b>. 실제 시험에서도 쓰는 방법이에요. 다 고르고 채점하면 스크립트에 정답 근거 문장이 표시돼요.",
         "<b>Astuce Part 3·4</b> <b>Lisez les questions avant l'audio</b>. C'est aussi la méthode à appliquer à l'examen. Après la correction, la phrase-indice est surlignée dans la transcription.")])
R(464, [("<b>Part 6·7 요령</b> 문제를 먼저 읽고 지문에서 근거를 찾으세요. 채점한 뒤 <b>근거 위치 보기</b>를 누르면 지문에 표시돼요.",
         "<b>Astuce Part 6·7</b> Lisez les questions, puis cherchez l'indice dans le texte. Après la correction, touchez <b>Voir l'indice</b> pour le surligner.")])
S(465, "Temps écoulé. Place à la correction")
S(466, "Relisez l'explication et l'indice")
S(467, "{0} thèmes · leçons clés + exercices")
S(468, "{0}/{1} questions · justes : {2}")
S(469, "{0} questions")
R(470, [("완료", "Terminé")])
R(471, [("{1}문법 랜덤 20제", "{1}Grammaire · 20 au hasard"), ("{2}시간 압박 20제 · 문항당 20초{3}", "{2}Contre-la-montre · 20 questions · 20 s chacune{3}"),
        ("{4}틀린 문법 문제 다시 ({5})", "{4}Refaire les erreurs ({5})")])
S(472, "Grammaire · 20 au hasard")
S(473, "Part 5 Contre-la-montre · 20 questions")
S(474, "Aucune question de grammaire ratée")
S(475, "{0} · {1} questions")
R(476, [("<b>함정 주의</b>", "<b>Attention au piège</b>"), ("{3}문제 {4}개 풀기", "{3}Faire les {4} questions")])
S(477, "Temps écoulé")
S(478, "{0} s")
S(479, "Temps écoulé · réponse : {0}")
S(480, "Faux · réponse : {0}")
R(481, [("{4} '{5}' 강의 보기", "{4} Voir la leçon « {5} »")])
R(482, [("<kbd>4</kbd> 선택 · <kbd>Enter</kbd> 다음", "<kbd>4</kbd> choisir · <kbd>Enter</kbd> suivant")])
S(483, "Temps écoulé ! Voici la réponse")
R(484, [("<b>함정</b>", "<b>Piège</b>"), ("문제로 돌아가기", "Retour à la question")])
S(485, "La dictée révèle les mots que vous ne saisissez pas à l'oreille")
R(486, [("<b>이렇게 하세요</b> 문장을 듣고 들리는 대로 쓰세요. 대소문자·문장부호는 채점하지 않아요. 틀린 단어는 빨간색으로 표시되고, 따라 말하기로 입에 붙일 수 있어요.",
         "<b>Mode d'emploi</b> Écoutez la phrase et écrivez ce que vous entendez. Majuscules et ponctuation ne comptent pas. Les mots faux s'affichent en rouge ; répétez-les à voix haute pour les ancrer."),
        ("<b>짧은 문장</b><span>LC 빈출 표현 {2}개 중 10문장</span>", "<b>Phrases courtes</b><span>10 phrases parmi {2} expressions LC</span>"),
        ("<b>긴 문장</b><span>Part 3·4 대화 문장 {4}개 중 10문장</span>", "<b>Phrases longues</b><span>10 phrases parmi {4} des Part 3·4</span>")])
S(487, "Dictée · phrases courtes")
S(488, "Dictée · phrases longues")
S(489, "Aucune phrase")
S(490, "(vide)")
R(491, [("{4}%</b>", "{4}\u00a0%</b>"), ("내가 쓴 문장: ", "Votre phrase : "), ("{5}/{6} 단어", "{5}/{6} mots"), ("{7}따라 말하기", "{7}Répéter")])
R(492, [('placeholder="들리는 대로 쓰세요"', 'placeholder="Écrivez ce que vous entendez"')])
S(493, "Phrase suivante")
R(494, [('aria-label="듣기"', 'aria-label="Écouter"'), ("{3}천천히", "{3}Lentement"),
        ("<kbd>Enter</kbd> 확인 · ", "<kbd>Enter</kbd> valider · "), ("<kbd>Space</kbd> 다시 듣기", "<kbd>Space</kbd> réécouter")])
S(495, "Test blanc complet n° {0}")
S(496, "Vocabulaire")
S(497, "Demi-test blanc n° {0}")
R(498, [("첫 응시 · 재응시 {1}점 ({2}회째)", "1er essai · nouvel essai {1} pts ({2}e)")])
R(499, [("LC {1}문제 · RC {2}문제 (RC {3}분)", "LC {1} questions · RC {2} questions (RC {3} min)")])
S(500, " (mode examen)")
S(501, " · RC : {0} min restantes")
R(502, [("풀던 모의고사가 있어요{1} · {2}문제 답함{3}", "Test en cours{1} · {2} réponses données{3}"),
        ("이어서 풀기", "Reprendre"), ("처음부터", "Recommencer")])
R(503, [("{1}전체 열기로 응시하기", "{1}Tout débloquer pour le passer")])
S(504, "Repasser")
S(505, "Passer le test")
S(506, "Tests blancs")
S(507, "{0}{1} demi-tests · score estimé")
R(508, [("<h2>정규 모의고사</h2>", "<h2>Tests blancs complets</h2>"), ("실제 시험과 같은 200문제 · 약 2시간", "200 questions comme à l'examen · env. 2 h")])
R(509, [("실제 시험처럼 <b>해설 없이</b> 끝까지 풀고, 마지막에 <b>LC·RC 예상 점수</b>와 파트별 정답률, 전체 해설을 보여 드려요. ",
         "Comme à l'examen, allez jusqu'au bout <b>sans explications</b> ; à la fin, vous obtenez votre <b>score estimé LC et RC</b>, votre réussite par partie et toutes les explications. "),
        ("LC는 <b>실전 진행</b>(시험장 방송처럼 안내 방송 → 번호 → 문제 → 답 고르는 시간 → 자동으로 다음)과 <b>내 속도로</b>(한 번 듣고 직접 넘기기) 중에서 시작할 때 고를 수 있어요. ",
         "Pour le LC, choisissez au départ entre le <b>mode examen</b> (comme en salle : consignes → numéro → question → temps de réponse → suite automatique) et <b>À votre rythme</b> (une écoute, vous passez vous-même). "),
        ("정규 모의고사는 실전 진행이 기본이에요. 점수는 <b>첫 응시</b>가 기준이고, 다시 풀면 '재응시'로 따로 표시돼요. 모의고사 문제는 연습 문제에 나오지 않아요.",
         "Les tests complets sont en mode examen par défaut. Le score de référence est celui du <b>premier essai</b> ; les suivants sont marqués « nouvel essai ». Les questions des tests blancs n'apparaissent pas dans les exercices."),
        ("<h2>하프 모의고사</h2>", "<h2>Demi-tests blancs</h2>"), ("절반 분량 · 약 1시간", "moitié de l'examen · env. 1 h")])
S(510, " LC env. 45 min · RC 75 min, comme à l'examen. Prévoyez 2 heures.")
S(511, " (recommencer efface vos réponses en cours)")
R(512, [("이미 푼 모의고사예요 (첫 응시 {0}점). 다시 풀면 <b>재응시</b>로 표시되고 예상 점수에는 반영되지 않아요.",
         "Test déjà passé (1er essai : {0} pts). Un nouveau passage sera marqué <b>nouvel essai</b> et ne comptera pas dans le score estimé.")])
R(513, [("LC → RC 순서로 진행하고, 해설은 끝난 뒤에 보여 드려요.{1} 중간에 나가도 답안이 저장돼서 이어서 풀 수 있어요{2}. 조용한 곳에서 이어폰을 끼고 시작하세요.",
         "LC puis RC ; les explications s'affichent à la fin.{1} Si vous quittez, vos réponses sont enregistrées et vous pourrez reprendre{2}. Installez-vous au calme avec des écouteurs."),
        ('data-close style="flex:1">취소</button>', 'data-close style="flex:1">Annuler</button>'),
        ('data-go-mock style="flex:1">시작</button>', 'data-go-mock style="flex:1">Commencer</button>')])
S(514, "Mode examen (comme le jour J)")
R(515, [("파트마다 영어 안내 방송이 나오고, 문항 번호를 불러 준 뒤 문제를 들려줘요. 답 고르는 시간(Part 1·2는 5초, Part 3·4는 질문마다 8초)이 지나면 <b>자동으로 다음 문제</b>로 넘어가요. 다시 듣기는 없어요.",
         "Consignes en anglais à chaque partie, puis numéro et question. Une fois le temps de réponse écoulé (5 s en Part 1·2, 8 s par question en Part 3·4), vous passez <b>automatiquement à la question suivante</b>. Pas de réécoute.")])
S(516, "À votre rythme")
R(517, [("문제 음성이 한 번 나오고, 답을 고른 뒤 <b>직접 '다음'</b>을 눌러 넘겨요. 처음 모의고사를 풀거나 천천히 연습할 때 좋아요.",
         "L'audio est lu une fois ; après avoir répondu, touchez <b>vous-même « Suivant »</b>. Idéal pour un premier test ou pour s'entraîner tranquillement.")])
R(518, [("듣기(LC) 진행 방식", "Déroulement de l'écoute (LC)"),
        ("RC는 두 방식 모두 같아요 (시간 제한, 문제 사이 자유 이동). 실전 진행 중에도 급한 일이 생기면 <b>일시정지</b>할 수 있어요.",
         "Le RC est identique dans les deux modes (temps limité, navigation libre). En mode examen, vous pouvez aussi faire <b>pause</b> en cas d'urgence.")])
S(519, "{0} Consignes : {1}")
R(520, [("{2}초", "{2} s")])
S(521, "Compréhension orale")
S(522, "{0} Écoute du n° {1}")
S(523, "Temps de réponse")
S(524, "{0} Écoute des n° {1} à {2}")
S(525, "{0} Question {1}")
S(526, "N° {0} : temps de réponse")
S(527, "{0} Fin de la compréhension orale")
R(528, [("{1}<small>번</small>", "<small>n° </small>{1}")])
R(529, [("보기 {3}", "Option {3}")])
R(530, [('aria-label="듣기"', 'aria-label="Écouter"'), ("질문과 보기 (A)(B)(C)가 한 번 재생돼요", "La question et les options (A)(B)(C) sont lues une fois")])
S(531, "{0} En pause · touchez « Continuer » pour reprendre à cette question")
S(532, "{0} Préparation…")
S(533, "Continuer")
S(534, "Commencer le RC ({0} min)")
S(535, "Question suivante ›")
R(536, [("안내 건너뛰기", "Passer les consignes")])
R(537, [("이전", "Précédent")])
S(538, "Rendre la copie")
R(539, [("답안지 보기 (RC {0}/{1})", "Feuille de réponses (RC {0}/{1})")])
R(540, [('aria-label="닫기"', 'aria-label="Fermer"')])
S(541, "Temps écoulé. Votre copie est rendue")
S(542, "Rendre votre copie ?")
S(543, "{0} questions sans réponse. Elles seront comptées comme fausses.")
R(544, [("답안지 <span", "Feuille de réponses <span"), ("RC {0}/{1} · 남은 시간 {2}", "RC {0}/{1} · reste {2}"),
        ('data-close style="flex:1">닫기</button>', 'data-close style="flex:1">Fermer</button>'),
        ('data-submit style="flex:1">제출하기</button>', 'data-submit style="flex:1">Rendre la copie</button>')])
S(545, "Mode examen : la suite s'enchaîne au rythme de l'audio")
S(546, "En mode examen, l'audio n'est lu qu'une fois")
S(547, "Pas de réécoute en mode examen")
S(548, "Test de niveau (10 min)")
S(549, "20 questions pour évaluer votre niveau")
R(550, [("진단 결과 ({0})", "Résultat du test ({0})"), ("<small>점</small>", "<small> pts</small>"),
        ("<b>{4}점</b>목표까지", "<b>{4} pts</b>avant l'objectif"),
        ("진단은 한 번만 해요. 이제 실전 문제를 풀수록 예상 점수가 더 정확해지고, <b>하프 모의고사</b>로 실력을 다시 확인할 수 있어요.",
         "Ce test ne se fait qu'une fois. Plus vous faites d'exercices, plus le score estimé est précis, et un <b>demi-test blanc</b> vous permet de refaire le point."),
        ("{5}하프 모의고사 보러 가기", "{5}Passer un demi-test blanc")])
R(551, [("<b>LC 10문제</b>", "<b>LC · 10 questions</b>"),
        ("Part 2 응답 4 · Part 3 대화 3 · Part 4 담화 3 (음성은 한 번씩)", "Part 2 Questions-réponses 4 · Part 3 Conversations 3 · Part 4 Exposés 3 (une seule écoute)"),
        ("<b>RC 10문제 · 10분</b>", "<b>RC · 10 questions · 10 min</b>"),
        ("Part 5 빈칸 6 · Part 7 독해 4", "Part 5 Phrases à compléter 6 · Part 7 Lecture 4"),
        ("<b>결과</b>", "<b>Résultat</b>"),
        ("예상 점수 · 목표까지 남은 점수 · 약한 파트 · 맞춤 학습 계획", "Score estimé · points manquants · parties faibles · plan d'étude personnalisé"),
        ("조용한 곳에서 이어폰을 끼고 시작하세요. 모르는 문제는 찍어도 괜찮아요. 지금 실력을 그대로 보는 게 목적이에요.",
         "Installez-vous au calme avec des écouteurs. Si vous ne savez pas, répondez au hasard : le but est de mesurer votre niveau actuel."),
        ("{3}진단 시작 (약 12분)", "{3}Commencer (env. 12 min)"), ("나중에 할게요", "Plus tard")])
S(552, "Disponible à tout moment via « Test de niveau (10 min) » sur l'accueil")
S(553, "ToeicFit en accès complet")
S(554, " + <b>{0}</b> tests blancs complets")
R(555, [("<li>단어 <b>{2}개</b> 전체 · 원어민 음성 · 90일 코스</li>", "<li>Les <b>{2}</b> mots · audio natif · parcours de 90 jours</li>"),
        ("<li>Part 1~7 실전 문제 <b>전부</b> · 정답 근거 해설</li>", "<li><b>Tous</b> les exercices Part 1 à 7 · explications avec indices</li>"),
        ("<li>하프 모의고사 <b>{3}회</b>{4} · 예상 점수</li>", "<li><b>{3}</b> demi-tests blancs{4} · score estimé</li>"),
        ("<li>문법 강의 30주제 · LC 표현 · 받아쓰기 무제한</li>", "<li>30 leçons de grammaire · expressions LC · dictée illimitée</li>"),
        ("{5}전체 열기 {6} · 출시 할인", "{5}Tout débloquer {6} · offre de lancement"),
        ("무료로 {8}일 먼저 써 보기", "Essayer {8} jours gratuitement")])
S(556, "Plus que <b>{1} pts</b> pour atteindre <b>{0} pts</b>")
S(557, "Vous avez déjà le niveau {0} pts ! Consolidez avec les mots de niveau Score élevé et les tests blancs")
R(558, [("지금 실력 · 진단 20문제 기준", "Niveau actuel · sur 20 questions"), ("<small>점</small>", "<small> pts</small>")])
R(559, [("시험까지 <b>D-{1}</b> · 매일 하면 목표 범위를 시험 전에 끝내요", "Examen à <b>J-{1}</b> · en étudiant chaque jour, vous finirez votre programme à temps")])
R(560, [("가장 약한 파트 <b>{1}</b> · 오늘의 실전에서 먼저 연습해요", "Partie la plus faible : <b>{1}</b> · travaillée en priorité dans la pratique du jour")])
R(561, [("<b>맞춤 학습 계획</b>", "<b>Plan d'étude personnalisé</b>"),
        ("하루 약 <b>{1}분</b> · 새 단어 {2}개 + 복습 + 오늘의 실전", "Env. <b>{1} min</b> par jour · {2} nouveaux mots + révisions + pratique du jour"),
        ("20문제로 낸 대략적인 점수예요. 실전 문제를 풀수록 예상 점수가 정확해져요.", "Score approximatif sur 20 questions. Il s'affine au fil des exercices.")])
R(562, [("{0}진단 문제 해설 보기", "{0}Voir les explications du test")])
S(563, "Visez {0} pts avec ToeicFit")
R(564, [("{0}학습 시작하기", "{0}Commencer à étudier")])
R(565, [("재응시 · {0}회째", "Nouvel essai · {0}e passage")])
S(566, "Score du nouvel essai (indicatif)")
S(567, "Score estimé (approx.)")
R(568, [("<b>이미 풀어 본 문제라 실제보다 높게 나올 수 있어요.</b> 첫 응시 점수 <b>{0}점</b>이 더 정확한 기준이에요. 이번 결과는 예상 점수와 약점 분석에 넣지 않았어요. 틀린 문제 해설을 다시 보는 복습용으로 활용하세요.",
         "<b>Vous connaissiez déjà ces questions : ce score peut être surévalué.</b> Votre score du 1er essai, <b>{0} pts</b>, est une référence plus fiable. Ce résultat n'entre ni dans le score estimé ni dans l'analyse des points faibles. Servez-vous-en pour relire les explications de vos erreurs.")])
R(569, [("<b>목표 {0}점 달성 수준이에요!</b> 남은 모의고사로 실력을 굳히고, 틀린 문제 해설을 꼭 보세요.",
         "<b>Niveau {0} pts atteint !</b> Consolidez avec les tests restants et lisez bien les explications de vos erreurs.")])
R(570, [("<b>목표 {0}점까지 약 {1}점</b> {2}가 상대적으로 약해요. 아래 파트별 정답률에서 낮은 파트부터 연습하세요.",
         "<b>Encore env. {1} pts pour atteindre {0} pts</b> Point plutôt faible : {2}. Travaillez d'abord les parties où votre réussite est la plus basse ci-dessous.")])
R(571, [("<small>점</small>", "<small> pts</small>"), ("LC {5}/{6} · RC {7}/{8} 정답", "LC {5}/{6} · RC {7}/{8} justes")])
S(572, "Questions-réponses")
S(573, " · erreurs seulement")
S(574, "Résultats")
R(575, [('aria-label="결과로"', 'aria-label="Retour aux résultats"'), ("해설 · {5}{6}", "Explications · {5}{6}"),
        ("{8}>이전</button>", "{8}>Précédent</button>")])
S(576, "60 séries de mots souvent confondus en Part 5")
R(577, [("{1}혼동 어휘 퀴즈 풀기", "{1}Quiz Mots à ne pas confondre")])
S(578, "Rechercher un mot")
R(579, [('placeholder="영어 또는 한국어 뜻으로 검색"', 'placeholder="Chercher en anglais ou en français"')])
R(580, [("{0}개", "{0} résultats")])
R(581, [("<b>검색 결과가 없어요</b>철자를 확인하거나 다른 뜻으로 찾아보세요", "<b>Aucun résultat</b>Vérifiez l'orthographe ou essayez un autre sens")])
R(582, [("<b>{1}개 토익 단어에서 찾아요</b>파생어·동의어·한국어 뜻으로도 검색돼요", "<b>Recherche parmi {1} mots TOEIC</b>Dérivés, synonymes et sens en français acceptés")])
R(583, [('title="{2} · {3}개"', 'title="{2} · {3} mots"')])
S(584, "Di"); S(585, "Lu"); S(586, "Ma"); S(587, "Me"); S(588, "Je"); S(589, "Ve"); S(590, "Sa")
S(591, "Auj.")
S(592, "Statistiques")
S(593, "Objectif {0} pts · {1}")
S(594, "Premier tour du programme terminé !")
S(595, "À ce rythme, premier tour fini le {0}")
S(596, "Terminé bien avant l'examen ({0}) 👍")
S(597, "Avant l'examen ({0}), commencez par les mots faciles et misez sur les exercices")
S(598, "Pour finir avant l'examen ({0}), augmentez votre rythme quotidien")
S(599, "Fixez la date d'examen dans Paramètres pour un suivi adapté")
S(600, " pts (LC {0} · RC {1})")
S(601, "Score estimé (d'après votre réussite récente)")
S(602, "Faites 30 questions en LC et en RC pour obtenir un score estimé")
R(603, [("<h2>실전 문제</h2>", "<h2>Exercices</h2>"), ("실전으로 →", "Pratique →")])
S(604, " · {0} pts")
R(605, [("암기 완료 / {2}", "Mémorisés / {2}"), ("학습한 단어", "Mots étudiés"),
        ('<span style="font-size:16px">일</span>', '<span style="font-size:16px"> j</span>'),
        ("연속 학습 · 최고 {5}일", "Série · record {5} j"), ('<div class="stat-lbl">정답률</div>', '<div class="stat-lbl">Réussite</div>'),
        ("<h2>난이도별 진도</h2>", "<h2>Progression par niveau</h2>"), ("<h2>최근 7일</h2>", "<h2>7 derniers jours</h2>"),
        ('aria-label="최근 7일 학습량"', 'aria-label="Activité des 7 derniers jours"'),
        ("</i>새 단어</span>", "</i>Nouveaux mots</span>"), ("</i>복습</span>", "</i>Révisions</span>"),
        ("<h2>학습 달력 (4주)</h2>", "<h2>Calendrier (4 semaines)</h2>"), ("<h2>Day 테스트</h2>", "<h2>Tests Day</h2>"),
        ("통과한 Day (80점 이상) · 응시 {19}", "Days réussis (80 pts ou +) · passés : {19}")])
S(606, "Guide d'utilisation")
S(607, "3 minutes pour bien utiliser ToeicFit")
S(608, "D'abord les révisions")
S(609, "Les mots appris jusqu'à hier, en commençant par ceux que vous risquez d'oublier. Les faire d'abord aide à retenir.")
S(610, "Nouveaux mots")
S(611, "{1} par jour, adaptés à l'objectif {0} pts. Vérifiez le sens en cartes, puis terminez par un quiz.")
S(612, "Pratique du jour")
S(613, "10 min d'exercices adaptés à votre objectif et à votre progression. Dès 2 semaines avant l'examen, place aux demi-tests blancs.")
S(614, "1 j"); S(615, "3 j"); S(616, "7 j"); S(617, "14 j"); S(618, "30 j")
S(619, "1re révision")
S(620, "Combien de mots par jour ?")
S(621, "Par défaut, le nombre est calculé selon votre objectif et la date d'examen. Vous pouvez le réduire si vous manquez de temps, mais <b>révisez chaque jour</b>. Modifiable à tout moment dans Paramètres → Plan d'étude.")
S(622, "Et si je saute un jour ?")
S(623, "Les révisions en retard arrivent toutes le lendemain. S'il y en a beaucoup, contentez-vous des révisions ce jour-là. Reprenez les nouveaux mots une fois les révisions faites.")
S(624, "On me propose trop de mots que je connais déjà")
S(625, "Faites Paramètres → <b>Test de vocabulaire</b>. En 3 minutes, il vous fait sauter les niveaux que vous maîtrisez. Vous pouvez aussi toucher « Je sais » directement sur la carte.")
S(626, "Changer d'objectif efface-t-il ma progression ?")
S(627, "Non. Vos mots appris et votre historique sont conservés ; seuls le programme et le niveau des prochains mots changent.")
S(628, "Faut-il une connexion Internet ?")
S(629, "Non. Mots, audio et questions sont tous dans l'app : elle fonctionne même en mode avion.")
S(630, "Comment transférer ma progression sur un nouveau téléphone ?")
S(631, "Créez un fichier via Paramètres → <b>Sauvegarder la progression</b>, puis utilisez <b>Restaurer une sauvegarde</b> sur le nouveau téléphone. Vos données ne sont stockées que sur cet appareil.")
S(632, "Quelle différence entre mode examen et À votre rythme ?")
S(633, "Le <b>mode examen</b> reproduit l'examen : consignes et numéros sont lus, et l'app passe seule à la question suivante une fois le temps de réponse écoulé. Sans réécoute possible, c'est idéal pour se mettre en conditions réelles. En mode <b>À votre rythme</b>, l'audio est lu une fois et vous touchez « Suivant » vous-même. Nous conseillons le mode examen dès 2 à 3 semaines avant l'examen. Si vous recevez un appel, touchez <b>Pause</b> : l'écoute reprendra à cette question.")
S(634, "Les exercices sont-ils des questions officielles ?")
S(635, "Non. Toutes les questions sont inédites et suivent le format réel du TOEIC. Indices et traductions sont inclus.")
R(636, [("{1}하루 학습 루틴", "{1}Routine quotidienne"),
        ("홈의 <b>오늘의 학습</b> 버튼이 아래 순서대로 다음 할 일을 알려 줘요. 버튼만 따라가면 돼요.",
         "Sur l'accueil, le bouton <b>Séance du jour</b> vous indique la prochaine étape, dans cet ordre. Il suffit de le suivre."),
        ("{5}단어 카드 버튼의 뜻", "{5}Les boutons des cartes"),
        ('<span class="badge bad">모름</span><span class="small">이번 학습 안에서 다시 나오고 오답노트에 모여요</span>',
         '<span class="badge bad">Je ne sais pas</span><span class="small">Revient dans la séance et va dans le carnet d\'erreurs</span>'),
        ('<span class="badge warn">헷갈림</span><span class="small">복습 간격을 한 단계 줄여요 (새 단어는 내일)</span>',
         '<span class="badge warn">J\'hésite</span><span class="small">Raccourcit l\'intervalle d\'un cran (demain pour un nouveau mot)</span>'),
        ('<span class="badge ok">알아요</span><span class="small">복습 간격이 점점 길어져요</span>',
         '<span class="badge ok">Je sais</span><span class="small">L\'intervalle s\'allonge peu à peu</span>'),
        ("처음 보는데 이미 아는 단어는 <b>알아요</b>를 누르면 3일 뒤 한 번 확인하고 넘어가요. 카드를 오른쪽으로 밀면 알아요, 왼쪽은 모름이에요.",
         "Pour un nouveau mot déjà connu, touchez <b>Je sais</b> : il sera vérifié une seule fois, dans 3 jours. Glisser à droite = Je sais, à gauche = Je ne sais pas."),
        ("{6}복습은 언제 나와요?", "{6}Quand reviennent les révisions ?"),
        ("맞힐 때마다 다음 복습까지의 간격이 늘어나고, 틀리면 처음부터 다시 짧아져요. 14일 간격까지 올라가면 <b>암기 완료</b>로 쳐요. 틀린 단어는 <b>복습 → 오답노트</b>에 자동으로 모여요.",
         "Chaque bonne réponse allonge l'intervalle avant la révision suivante ; une erreur le ramène au début. À 14 jours d'intervalle, le mot est <b>mémorisé</b>. Les mots ratés vont automatiquement dans <b>Révisions → Carnet d'erreurs</b>."),
        ("{8}예상 점수와 하프 모의고사", "{8}Score estimé et demi-tests blancs"),
        ("<b>예상 점수</b>는 최근에 푼 LC·RC 문제(각 30문제 이상)의 정답률로 계산해요. 많이 풀수록 정확해져요.",
         "Le <b>score estimé</b> est calculé d'après votre réussite récente en LC et en RC (au moins 30 questions chacun). Plus vous pratiquez, plus il est précis."),
        ("<b>하프 모의고사</b>는 실제 시험의 절반 분량이에요. LC 음성은 한 번만 나오고 RC는 시간을 재요. 모의고사 문제는 연습 문제에 나오지 않아서 처음 보는 문제로 실력을 잴 수 있어요.",
         "Le <b>demi-test blanc</b> fait la moitié de l'examen réel. L'audio LC n'est lu qu'une fois et le RC est chronométré. Ses questions n'apparaissent pas dans les exercices : votre niveau est mesuré sur des questions inédites."),
        ('<b>실전 진행</b>을 고르면 시험장 방송처럼 LC가 흘러가요. 파트마다 영어 안내 방송 → "Number 7." 번호 → 문제 음성 → 답 고르는 시간(Part 1·2 5초, Part 3·4 질문마다 8초) → 자동으로 다음 문제. 정규 모의고사는 실전 진행이 기본이고, 하프 모의고사는 시작할 때 고를 수 있어요.',
         'En <b>mode examen</b>, le LC se déroule comme en salle d\'examen : consignes en anglais à chaque partie → numéro ("Number 7.") → audio de la question → temps de réponse (5 s en Part 1·2, 8 s par question en Part 3·4) → question suivante automatiquement. Les tests complets sont en mode examen par défaut ; pour les demi-tests, vous choisissez au départ.'),
        ("같은 회차를 다시 풀면 <b>재응시</b>로 따로 표시되고 예상 점수에는 넣지 않아요. 첫 응시 점수가 기준이에요.",
         "Repasser un même test le marque comme <b>nouvel essai</b>, sans effet sur le score estimé. Le score du premier essai fait foi."),
        ("{9}파트별 요령 한 줄", "{9}Une astuce par partie"),
        ("<b>Part 1</b> 사람 없는 사진의 'is being p.p.'(지금 ~되는 중)는 대부분 오답", "<b>Part 1</b> Sur une photo sans personne, 'is being p.p.' (action en cours) est presque toujours faux"),
        ("<b>Part 2</b> 돌려 말하는 응답('확인해 볼게요')이 정답인 경우가 많아요", "<b>Part 2</b> La réponse indirecte (« Let me check ») est souvent la bonne"),
        ("<b>Part 3·4</b> 음성 전에 문제를 먼저 읽어 두기", "<b>Part 3·4</b> Lire les questions avant l'audio"),
        ("<b>Part 5</b> 빈칸 앞뒤의 품사 자리부터 확인", "<b>Part 5</b> Repérer d'abord la nature du mot attendu autour du blanc"),
        ("<b>Part 6</b> 문장 삽입은 앞뒤 문장과의 연결이 핵심", "<b>Part 6</b> Insertion de phrase : tout repose sur le lien avec les phrases voisines"),
        ("<b>Part 7</b> 정답은 지문의 말을 다른 표현으로 바꿔 나와요", "<b>Part 7</b> La bonne réponse reformule les mots du texte"),
        ("<h2>자주 묻는 질문</h2>", "<h2>Questions fréquentes</h2>"),
        ("{18}시작 미션 다시 보기", "{18}Revoir les missions de départ"), ("{19}화면 팁 다시 보기", "{19}Revoir les astuces")])
S(637, "Missions de départ réaffichées sur l'accueil")
S(638, "Les astuces réapparaîtront une fois sur chaque écran")
S(639, "Paramètres")
S(640, "Examen le {0}")
S(641, "Date d'examen non fixée")
S(642, "Refaire")
S(643, "Faire")
S(644, "Mots de niveau {0} sautés actuellement")
S(645, "Test de 3 min pour sauter les mots connus")
R(646, [("<b>건너뛴 단어 다시 포함</b>", "<b>Réintégrer les mots sautés</b>"), ("{0} 단어를 오늘의 학습에 다시 넣어요", "Remet les mots de niveau {0} dans la séance du jour")])
S(647, "Rappel quotidien")
S(648, "Rappel des mots du jour à l'heure choisie")
R(649, [("<b>알림 시간</b>", "<b>Heure du rappel</b>")])
S(650, "Prononciation auto")
S(651, "Lit le mot dès qu'il s'affiche (cartes, fiches)")
S(652, "Exemples en lecture auto")
S(653, "Lit l'exemple quand vous retournez la carte")
S(654, "Effets sonores")
S(655, "Sons de bonne et mauvaise réponse")
S(656, "Langue")
S(657, "Auto (langue de l'appareil)")
S(658, "Auto")
S(659, "Clair")
S(660, "Sombre")
S(661, "Traduction des exemples")
S(662, "Désactivée : exemples en anglais seulement")
S(663, "Premium actif")
S(664, "Débloquer les {0} jours avec Premium")
R(665, [("프리미엄", "Premium")])
R(666, [("<div class=\"set-title\">학습 계획</div>", "<div class=\"set-title\">Plan d'étude</div>"),
        ("<b>목표 점수 · 시험일 · 하루 학습량</b>", "<b>Score visé · date d'examen · mots par jour</b>"),
        ("<span>{1}점 · {2} · 하루 {3}개</span>", "<span>{1} pts · {2} · {3} par jour</span>"),
        ("<b>어휘 진단 {5}</b>", "<b>{5} le test de vocabulaire</b>"),
        ("<div class=\"set-title\">소리</div>", "<div class=\"set-title\">Son</div>"),
        ("<b>재생 속도</b>", "<b>Vitesse de lecture</b>"),
        ("<div class=\"set-title\">화면</div>", "<div class=\"set-title\">Affichage</div>"),
        ("<b>테마</b>", "<b>Thème</b>"),
        ("<div class=\"set-title\">데이터</div>", "<div class=\"set-title\">Données</div>"),
        ("<b>학습 기록 백업</b><span>파일로 저장해 다른 기기로 옮길 수 있어요</span>", "<b>Sauvegarder la progression</b><span>Fichier à transférer sur un autre appareil</span>"),
        ("<b>백업 불러오기</b>", "<b>Restaurer une sauvegarde</b>"),
        ("학습 기록 초기화</b><span>모든 진도와 기록을 지워요</span>", "Réinitialiser la progression</b><span>Efface toute la progression et l'historique</span>"),
        ("<div class=\"set-title\">도움말</div>", "<div class=\"set-title\">Aide</div>"),
        ("<b>사용 가이드</b><span>하루 학습 루틴 · 복습 원리 · 예상 점수 · 자주 묻는 질문</span>", "<b>Guide d'utilisation</b><span>Routine · révisions · score estimé · FAQ</span>"),
        ("<div class=\"set-title\">정보</div>", "<div class=\"set-title\">À propos</div>"),
        ("<b>버전</b>", "<b>Version</b>"), ("1.0.0 · 데이터 {22}", "1.0.0 · données {22}"),
        ("<b>오픈소스 라이선스</b>", "<b>Licences open source</b>"),
        ("<b>개인정보 처리방침</b><span>학습 기록은 기기에만 저장돼요</span>", "<b>Politique de confidentialité</b><span>Vos données restent sur l'appareil</span>"),
        ("이 앱은 ETS와 관련이 없습니다.", "Cette app n'est pas affiliée à ETS.")])
S(667, "Autorisez les notifications pour recevoir les rappels")
S(668, "Rappel tous les jours à {0}")
S(669, "Rappel désactivé")
S(670, "Mots sautés réintégrés")
S(671, "Effacer toute la progression ?")
S(672, "Progression, carnet d'erreurs et stats seront définitivement effacés. Pensez à sauvegarder d'abord.")
S(673, "Tout effacer")
S(674, "Réinitialisé")
S(675, "Sauvegarde ToeicFit")
S(676, "Fichier de sauvegarde de la progression")
S(677, "Enregistrer ou envoyer la sauvegarde")
S(678, "Sauvegarde créée")
S(679, "Échec de la création de la sauvegarde")
S(680, "Sauvegarde enregistrée")
S(681, "Restaurer la sauvegarde ?")
S(682, "La progression de cet appareil sera remplacée par celle de la sauvegarde.")
S(683, "Restaurer")
S(684, "Sauvegarde restaurée")
S(685, "Fichier de sauvegarde non valide")
S(686, "Licences open source")
R(687, [("발음기호 생성에 사용.", "Utilisé pour la transcription phonétique."),
        ("모든 단어·예문·문장 음성 합성에 사용.", "Utilisé pour la synthèse vocale des mots, exemples et phrases."),
        ("앱 글꼴.", "Police de l'app."), ("아이콘 모양 참고.", "Inspiration pour les icônes.")])
S(688, "Achats restaurés")
S(689, "Aucun achat à restaurer")
S(690, "Accès complet déjà actif")
S(691, "Impossible de vérifier vos achats")
S(692, "Essai gratuit : 1 série par partie")
S(693, "Essai gratuit : 1 thème de grammaire")
S(694, "Essai gratuit : 1 quiz LC")
S(695, "Essai gratuit : 1 dictée")
S(696, "Essai gratuit : 1 demi-test blanc")
S(697, "Essai gratuit : Day 1 à {0}")
S(698, "Tests blancs complets inclus dans l'accès complet")
S(699, "Contre-la-montre inclus dans l'accès complet")
R(700, [("전체 이용 중이에요", "Accès complet actif"), ("모든 단어·실전 문제·모의고사를 제한 없이 쓸 수 있어요. 감사합니다!", "Tous les mots, exercices et tests blancs, sans limite. Merci !")])
S(701, "Tout le TOEIC dans une seule app")
R(702, [("한 번 결제로 모든 기능을 평생 이용해요", "Un seul paiement, toutes les fonctions à vie")])
R(703, [("구매 복원", "Restaurer les achats"),
        ("결제는 Google Play·App Store 계정으로 안전하게 처리돼요. 구독이 아니라 자동 결제가 없어요.",
         "Paiement sécurisé via votre compte Google Play ou App Store. Pas d'abonnement, aucun prélèvement automatique.")])
S(704, "La restauration des achats nécessite l'app installée depuis le store")
S(705, "Le paiement nécessite l'app installée depuis le store")
S(706, "Accès complet débloqué ! Bon apprentissage")
S(707, "Paiement en attente de validation. Le déblocage sera automatique")
S(708, "Paiement annulé")
S(709, "Paiement non abouti. Réessayez dans un instant")
S(710, "Niveau Base")
S(711, "Vocabulaire TOEIC de base indispensable")
S(712, "Niveau Essentiel")
S(713, "Base + vocabulaire clé de l'examen")
S(714, "Niveau Score élevé")
S(715, "Base + Essentiel + vocabulaire avancé")
S(716, "questions")
