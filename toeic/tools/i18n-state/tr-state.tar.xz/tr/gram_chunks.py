# 문법 보강분(아직 번역 안 된 grammar 키)만 src/p-3N.json 묶음으로 만든다. 문맥(ctx)은 grammar.json 원본.
import json, re
T = '/home/user/script/toeic'
src = json.load(open(f'{T}/data/i18n/src.ko.json'))
en = json.load(open(f'{T}/data/i18n/en.json'))
G = {t['id']: t for t in json.load(open(f'{T}/data/practice/grammar.json'))}
H = re.compile('[가-힣]')
def clean(x):
    if isinstance(x, str): return '@' if H.search(x) else x
    if isinstance(x, list): return [clean(v) for v in x]
    if isinstance(x, dict): return {k: clean(v) for k, v in x.items() if k not in ('lv', 'mock')}
    return x
miss = [k for k in src['p'] if k.startswith('grammar/') and (k not in en['p'] or en['p'][k][0] != src['p'][k])]
recs = {}
for k in miss:
    s = k.split('/'); t = G[s[1][1:]]
    if s[2] == 'qs': root = '/'.join(s[:4]); ctx = clean(next(q for q in t['qs'] if q['id'] == s[3][1:]))
    elif s[2] == 'lesson': root = '/'.join(s[:4]); ctx = clean(t['lesson'][int(s[3])])
    else: root = '/'.join(s[:3]); ctx = {'topic_lesson_headings': [clean(l['h']) for l in t['lesson']], 'note': 'trap = common beginner mistake paragraph'}
    recs.setdefault(root, {'root': root, 'ctx': ctx, 'keys': {}})['keys'][k] = src['p'][k]
chunks, cur, size = [], [], 0
for r in recs.values():
    sz = sum(len(v) for v in r['keys'].values())
    if size + sz > 36000 and cur: chunks.append(cur); cur, size = [], 0
    cur.append(r); size += sz
if cur: chunks.append(cur)
for i, c in enumerate(chunks):
    json.dump(c, open(f'src/p-{31 + i}.json', 'w'), ensure_ascii=False, indent=1)
print(len(miss), 'keys', len(recs), 'records', len(chunks), 'chunks: p-31 ..', f'p-{30 + len(chunks)}')
