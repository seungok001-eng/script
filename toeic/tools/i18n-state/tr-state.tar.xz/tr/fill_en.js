// en p 키 중 {n} 빈칸이 남은 Part 6 해석에 정답을 채운다 (경로로 원본 세트를 찾아 qs[n-1].o[a])
const fs = require("fs");
const g = {}; new Function("window", fs.readFileSync("app/js/practice.js", "utf8"))(g);
const PR = g.VOCA_PRACTICE;
function resolve(path) {
  let cur = PR; const segs = path.split("/");
  for (const s of segs.slice(0, -2)) {
    if (cur == null) return null;
    if (s.startsWith("#")) cur = (Array.isArray(cur) ? cur : Object.values(cur)).find((x) => x && x.id === s.slice(1));
    else cur = cur[s];
  }
  return cur;
}
const files = process.argv.slice(2);
for (const f of files) {
  const d = JSON.parse(fs.readFileSync(f, "utf8"));
  const isApp = !!d.p; const tbl = isApp ? d.p : d; let n = 0, miss = 0;
  for (const k of Object.keys(tbl)) {
    const v = isApp ? tbl[k][1] : tbl[k];
    if (typeof v !== "string" || !/\{\d\}/.test(v) || !/\/ko\/\d+$/.test(k)) continue;
    const set = resolve(k);
    if (!set || !set.qs) { miss++; continue; }
    const w = v.replace(/\{(\d)\}/g, (m, i) => { const q = set.qs[+i - 1]; return q ? q.o[q.a] : m; });
    if (w !== v) { if (isApp) tbl[k] = [tbl[k][0], w]; else tbl[k] = w; n++; }
  }
  fs.writeFileSync(f, isApp ? JSON.stringify(d) : JSON.stringify(d, null, 1));
  console.log(f.split("/").pop(), "filled", n, "unresolved", miss);
}
