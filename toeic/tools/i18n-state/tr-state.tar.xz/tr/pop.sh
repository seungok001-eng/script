#!/bin/sh
# 대기열에서 n개 꺼내기 (이미 결과가 있는 것은 건너뜀)
cd "$(dirname "$0")"; n=${1:-1}; got=0
while [ $got -lt $n ] && [ -s queue.txt ]; do
  x=$(head -1 queue.txt); sed -i '1d' queue.txt
  [ -f "out/$x.json" ] && continue
  echo "$x"; got=$((got+1))
done
