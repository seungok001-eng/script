import json, re, sys, os
TR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ui = json.load(open(f'{TR}/ui.json', encoding='utf-8'))
keys = list(ui)
T = {}
for f in ['ui_a.txt', 'ui_b.txt', 'ui_c.txt']:
    txt = open(os.path.join(os.path.dirname(__file__), f), encoding='utf-8').read()
    parts = re.split(r'^@@ (\d+)\n', txt, flags=re.M)
    for i in range(1, len(parts), 2):
        n = int(parts[i]); body = parts[i+1]
        if body.endswith('\n'): body = body[:-1]
        assert n not in T, n
        T[n] = body
missing = [i for i in range(len(keys)) if i not in T]
assert not missing, missing
out = {keys[i]: T[i] for i in range(len(keys))}
# structural check: tags with translatable attribute values masked
ATTR = re.compile(r'\b(aria-label|alt|title|placeholder)="[^"]*"')
tags = lambda s: sorted(ATTR.sub(r'\1=""', t) for t in re.findall(r'</?[a-z][^>]*>', s))
bad = 0
for i, k in enumerate(keys):
    t = out[k]
    if tags(k) != tags(t): print('TAG', i, set(tags(k)) ^ set(tags(t))); bad += 1
    if sorted(re.findall(r'\{\d+\}', k)) != sorted(re.findall(r'\{\d+\}', t)): print('PH', i); bad += 1
    if re.search(r'[가-힣]', t): print('KO', i); bad += 1
    if k.startswith('\n') != t.startswith('\n'): print('NL', i)
labels = json.load(open(f'{TR}/labels.json', encoding='utf-8'))
L = {}
for line in open(os.path.join(os.path.dirname(__file__), 'labels.txt'), encoding='utf-8'):
    line = line.rstrip('\n')
    if not line: continue
    a, b = line.split('\t'); assert a not in L, a; L[a] = b
LO = {}
for k in labels:
    if k in L: LO[k] = L[k]
    elif k.endswith(' 심화') and k[:-3] in L: LO[k] = L[k[:-3]] + ' 進階'
    elif k.endswith(' 완성') and k[:-3] in L: LO[k] = L[k[:-3]] + ' 高階'
    else: print('LABEL MISSING', k); bad += 1
unused = [k for k in L if k not in labels]
if unused: print('unused labels', unused)
os.makedirs(f'{TR}/out', exist_ok=True)
json.dump(out, open(f'{TR}/out/zh-TW-ui.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
json.dump(LO, open(f'{TR}/out/zh-TW-labels.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('built', len(out), len(LO), 'issues', bad)
