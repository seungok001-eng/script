"""Source fixes after translation: edit ko source text and apply the same text fix in every out/<L>/p-*.json."""
import json, glob, os, re
R = '/home/user/script/toeic/data/practice/'
T = os.path.dirname(os.path.abspath(__file__))
FIX = []  # (old, new, per-language text replace pairs)
v5 = json.load(open(R + 'vocab5.json'))
for t in v5:
    for q in t['qs']:
        if q['id'] == 'v08-091' and 'be responsible for = be responsible for' in q['exp']:
            old = q['exp']; q['exp'] = old.replace('be responsible for = be responsible for = be liable for', 'be responsible for = be liable for')
            FIX.append((old, q['exp'], [('be responsible for = be responsible for = be liable for', 'be responsible for = be liable for')]))
json.dump(v5, open(R + 'vocab5.json', 'w'), ensure_ascii=False, indent=1)
p7 = json.load(open(R + 'p7.json'))
for x in p7:
    if x['id'] == 'p7-117':
        q = x['qs'][0]; old = q['exp']
        new = old.replace("핼로런 씨가 'agreed to exchange time slots with me, provided that you approve'라며 솔버그 씨의 승인을 구하고", "핼로런 씨가 'agreed to exchange time slots with me, provided that you approve'라고 전하며 솔버그 씨의 승인을 구하고").replace("기차 취소로 예정된 시간에 발표할 수 없다고 한 뒤, ", "윌크 씨는 기차 취소로 예정된 시간에 발표할 수 없다고 한 뒤, ")
        if new != old: q['exp'] = new; FIX.append((old, new, []))
    if x['id'] == 'p7-109':
        q = x['qs'][4]; q['exp'] = q['exp'].replace("첫 문장의 'Classes are held'", "같은 단락 첫 문장의 'Classes are held'")
json.dump(p7, open(R + 'p7.json', 'w'), ensure_ascii=False, indent=1)
for f in glob.glob(T + '/out/*/p-4[1-9].json') + glob.glob(T + '/out/*/p-5[0-2].json'):
    d = json.load(open(f)); ch = 0
    for old, new, reps in FIX:
        for k, v in list(d.items()):
            for a, b in reps:
                if isinstance(v, str) and a in v: d[k] = v = v.replace(a, b); ch += 1
    for k, v in list(d.items()):
        if isinstance(v, str) and re.search(r'(\d)[ \u00a0]m x (\d)m\b', v): d[k] = re.sub(r'(\d)[ \u00a0]m x (\d)m\b', r'\1 m x \2 m', v); ch += 1
    if ch: json.dump(d, open(f, 'w'), ensure_ascii=False, indent=1); print(f, ch)
print(len(FIX), 'source fixes')
# en: drop redundant self-glosses like "delay (delay)"
import re
for f in glob.glob(T + '/out/en/p-4[1-9].json') + glob.glob(T + '/out/en/p-5[0-2].json'):
    d = json.load(open(f)); n = 0
    for k, v in d.items():
        if isinstance(v, str):
            w = re.sub(r"\b([A-Za-z][A-Za-z' -]*?) \(\1\)", r"\1", v)
            if w != v: d[k] = w; n += 1
    if n: json.dump(d, open(f, 'w'), ensure_ascii=False, indent=1); print(f, 'self-gloss', n)
