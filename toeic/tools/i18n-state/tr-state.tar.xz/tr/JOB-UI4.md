# UI string translation job (new/changed app screens after a review round: result headers (정답률), practice-hub counts, paywall, onboarding plan, settings)
Work dir: /tmp/claude-0/-home-user-script/daeb160e-7d1b-5b97-88f4-a9d67a2fe616/scratchpad/tr/
1. Read TRANSLATE.md (strict rules) and out/L-glossary.md. Existing UI translations for style/terminology: out/L-ui.json (read a good sample;
   match its voice, button style, capitalization and terms — e.g. the product name "전체 이용권" must use ONE consistent term in L; pick the natural
   equivalent of "full pass / all-access pass" and use it everywhere in your chunk; Part names stay "Part 5"; Day stays "Day/DAY").
2. Input src-ui4/ui-N.json = {key: {ko, similar_old_ko?}}. The key IS the Korean source (may contain HTML and {0} placeholders).
   `similar_old_ko` points to an older version of a similar string; its existing L translation is in src-ui4/ref-L.json — reuse its wording where the meaning is unchanged.
   To understand context, grep the Korean text in /home/user/script/toeic/app/js/app.js (T`...` templates; ${...} became {0},{1}... in order).
3. Write out/L-ui4-N.json = flat {key: translation} for EVERY key (Python json.dump, ensure_ascii=False). Keep HTML tags/attributes, placeholders, emoji, English words exactly. UI text must be short (mobile buttons).
4. Run `python3 check.py src-ui4/ui-N.json out/L-ui4-N.json L` until OK. Then review every string once more as a native UI copy editor (consistency with out/L-ui.json terms) and re-run the checker.
Keep helper scripts in work/L-ui4-N/. Do not modify anything under /home/user/script. Final answer: one short paragraph (count, checker result, term choices, doubts).
