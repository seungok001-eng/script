T = {}
def R(i, d):
    for k, v in d.items(): T[f'words/#{i}/{k}'] = v
R('02-21', {
'm/0':'同僚',
'exKo':'Ms. Ahmed は役に立つ研究記事をよく同僚と共有している。',
'col/0/k':'元同僚','col/1/k':'親しい同僚',
'tip':'Part 2・3 では coworker、associate に言い換えられることが多い。可算名詞なので a colleague of mine または colleagues の形で使う。',
'q/k':'研修に参加している間、シフトの代わりを頼む相手は「同僚」なので colleague が正解。つづりの似た college（大学）、collection（収集品）、collector（収集家）と混同しないこと。'})
R('02-22', {
'm/0':'上司、管理者','m/1':'監督者',
'exKo':'機器のトラブルはすべて直ちに管理者に報告しなければならない。',
'col/0/k':'直属の上司','col/1/k':'シフト責任者',
'der/0/m':'監督する、管理する','der/1/m':'監督、管理',
'tip':'人を表す名詞 supervisor と行為を表す名詞 supervision（監督）を区別する問題がよく出る。「under the supervision of（〜の監督の下で）」も頻出だ。',
'q/k':'休暇の申請を承認するのは人なので、「直属の上司」を意味する supervisor が正解。supervision は「監督」という行為を表す名詞なので承認する主体にはなれない。'})
R('02-23', {
'm/0':'部下','m/1':'下位の者',
'exKo':'良い管理職は部下に明確な指示と役に立つフィードバックを与える。',
'col/0/k':'直属の部下','col/1/k':'〜より下位である',
'tip':'形容詞として「be subordinate to（〜より下位の）」の形でも使われる。Part 7 では direct report、team member に言い換えられる。',
'q/k':'チームリーダーとして指導し、仕事をチェックする相手は「部下」なので subordinates が正解。superiors（上司）、predecessors（前任者）、shareholders（株主）はチームリーダーが指導する相手ではない。'})
R('02-24', {
'm/0':'職員、人員','m/1':'人事部',
'exKo':'許可を受けた職員のみ実験室に入ることができる。',
'col/0/k':'権限のある職員','col/1/k':'人事部','col/2/k':'医療スタッフ',
'tip':'personnel は集合名詞で複数扱いし、つづりの似た personal（個人の）と混同しないこと。「personnel department」は human resources と同じ意味だ。',
'q/k':'形容詞 authorized に修飾される名詞の位置で、「権限のある職員」という意味なので personnel が正解。personal は形容詞、personally は副詞で、personality（性格）は意味が合わない。'})
R('02-25', {
'm/0':'（全体の）人員、労働力','m/1':'全従業員',
'exKo':'その会社は来年、人員を15パーセント増やす予定だ。',
'col/0/k':'人員を増やす','col/1/k':'熟練した労働力','col/2/k':'人員を削減する',
'tip':'会社の全従業員をひとまとまりとして表す単数名詞だ (the entire workforce)。Part 7 では staff、employees に言い換えられる。',
'q/k':'リモートで「働く」主体は人なので、会社の「全従業員」を意味する workforce が正解。workplace（職場）、workshop（研修会）、workload（業務量）は働く主体にはなれない。'})
R('02-26', {
'm/0':'士気、意欲',
'exKo':'新しいフレックスタイム制で従業員の士気が大いに高まった。',
'col/0/k':'士気を高める','col/1/k':'低い士気','col/2/k':'従業員の士気',
'tip':'つづりの似た moral（道徳的な、教訓）と混同しないこと。「boost/improve morale」が代表的なコロケーションで、不可算名詞だ。',
'q/k':'大変な1年を過ごした従業員の「士気」を高めるための行事なので morale が正解。moral（道徳、教訓）、mortal（死ぬ運命にある）、model（模型、モデル）は boost と意味が合わない。'})
R('02-27', {
'm/0':'動機づける','m/1':'やる気を起こさせる',
'exKo':'有能な管理職は繁忙期にチームのやる気を引き出す方法を知っている。',
'col/0/k':'Aに〜する気を起こさせる','col/1/k':'意欲にあふれた',
'der/0/m':'動機づけ、やる気','der/1/m':'意欲的な','der/2/m':'やる気を起こさせる',
'tip':'「motivate A to do」の形で使う。求人広告の「highly motivated individuals（意欲あふれる人材）」のように形容詞 motivated も頻出だ。',
'q/k':'to の後の動詞の原形の位置で、「motivate A to do（Aに〜する気を起こさせる）」の構造なので motivate が正解。motivation は名詞、motivational と motivated は形容詞だ。'})
R('02-28', {
'm/0':'褒める、称賛する',
'exKo':'評論家たちはそのホテルのレストランの独創的なメニューを称賛した。',
'col/0/k':'BのことでAを褒める','col/1/k':'高く評価される','col/2/k':'絶賛',
'der/0/m':'称賛に値する',
'tip':'「praise A for B（BのことでAを褒める）」の前置詞 for を覚えておくこと。名詞としても使われ、「receive praise from」のように不可算名詞として扱う。',
'q/k':'目的語 the staff と for B を一緒にとる「praise A for B」の構文なので praised が正解。complain、apologize、object は自動詞なので目的語を直接とれない。'})
R('02-29', {
'm/0':'（候補に）推薦する','m/1':'指名する',
'exKo':'Ms. Park は同僚たちから年間最優秀社員賞の候補に推薦された。',
'col/0/k':'AをBの候補に推薦する','col/1/k':'〜に指名される',
'der/0/m':'指名、推薦','der/1/m':'候補者、指名された人',
'tip':'「be nominated for ＋賞・役職」の形が頻出だ。人を表す名詞 nominee（候補者）と行為を表す名詞 nomination（推薦）を区別すること。',
'q/k':'助動詞 may の後の動詞の原形の位置なので nominate が正解。nomination と nominee は名詞、nominal（名目上の）は形容詞だ。'})
R('02-30', {
'm/0':'業績、成果','m/1':'達成',
'exKo':'政府との契約を勝ち取ったことが、今年のチームの最大の成果だった。',
'col/0/k':'主要な業績','col/1/k':'達成感',
'der/0/m':'成し遂げる、達成する','der/1/m':'熟達した、優れた',
'tip':'形容詞 accomplished は「熟達した、優れた (an accomplished pianist)」という意味なので、「完了した」とだけ解釈しないこと。accomplishment は可算名詞だ。',
'q/k':'冠詞 a と形容詞 remarkable の後の名詞の位置なので accomplishment が正解。accomplish は動詞、accomplished は形容詞なので名詞の位置には入らない。'})
R('02-31', {
'm/0':'有能な','m/1':'〜できる',
'exKo':'Mr. Hong は物流分野で長年経験を積んだ非常に有能な管理職だ。',
'col/0/k':'〜することができる','col/1/k':'非常に有能な',
'der/0/m':'能力、力量','der/1/m':'有能に、手際よく',
'tip':'「be capable of ＋ -ing」の形で使い、to不定詞は使わない。同じ意味の able は「be able to do」なので、2つの形を混同させる問題が出る。',
'q/k':'空所の後の of producing と結びつくのは「be capable of -ing」なので capable が正解。able は to不定詞と使い、possible と available は of -ing と一緒に使わない。'})
R('02-32', {
'm/0':'勤勉な','m/1':'熱心な',
'exKo':'Ms. Ford はいつも報告書を念入りに見直す勤勉な社員だ。',
'col/0/k':'勤勉な社員','col/1/k':'たゆまぬ努力',
'der/0/m':'勤勉、まじめさ','der/1/m':'熱心に、勤勉に',
'tip':'副詞 diligently が動詞を修飾する位置と、形容詞 diligent が名詞を修飾する位置を区別する問題として出題される。Part 7 では hardworking に言い換えられる。',
'q/k':'定冠詞 the と名詞 efforts の間で名詞を修飾する形容詞の位置なので diligent が正解。diligently と most diligently は副詞なので名詞を修飾できない。'})
R('02-33', {
'm/0':'時間を厳守する',
'exKo':'従業員はすべての顧客との会議に時間どおりに出席することが求められる。',
'col/0/k':'〜に時間どおりに来る','col/1/k':'期日どおりの支払い',
'der/0/m':'時間厳守','der/1/m':'時間どおりに',
'tip':'be punctual は Part 7 で「arrive on time」に言い換えられる。名詞 punctuality は人事評価の項目 (attendance and punctuality) としてよく出る。',
'q/k':'20分遅れて到着してチームが驚いたとあるので、普段は「時間を厳守する」人という意味の punctual が正解。generous（寛大な）、talkative（おしゃべりな）、cautious（慎重な）は遅刻と対比にならない。'})
R('02-34', {
'm/0':'欠勤、不在','m/1':'欠席',
'exKo':'Mr. Kerr の不在中は Ms. Diaz が顧客からの電話に対応する。',
'col/0/k':'〜の不在中に','col/1/k':'欠勤','col/2/k':'〜がない場合に',
'der/0/m':'欠席の、不在の','der/1/m':'欠席者',
'tip':'「in (during) one\'s absence（〜の不在中に）」の形で業務代行の文脈によく出る。形容詞 absent は「be absent from（〜を欠席する）」の形で使う。',
'q/k':'定冠詞 the の後、前置詞 of の前の名詞の位置で、「in the absence of（〜がいない場合に）」は決まった表現なので absence が正解。absentee は「欠席者」なので意味が合わない。'})
R('02-35', {
'm/0':'休職','m/1':'長期休暇',
'exKo':'Mr. Burke は父親の介護のために6か月間休職した。',
'col/0/k':'休職する','col/1/k':'休職を申請する','col/2/k':'休職中の',
'tip':'「on leave（休暇中の）」「maternity leave（産休）」のように leave は名詞で「休暇」として使われる。Part 7 で長期間不在にする理由を問う問題の根拠になる。',
'q/k':'大学院の勉強を終えるために1年間認められたのは「休職」なので leave of absence が正解。turnover（離職率）、attendance（出席）は意味が合わず、step down は動詞句なので冠詞の後には来ない。'})
R('02-36', {
'm/0':'（役職から）退く','m/1':'辞任する',
'exKo':'会社の創業者は年末に会長職を退く。',
'col/0/k':'〜の職を退く','col/1/k':'〜から退く',
'tip':'「step down as ＋職名」「step down from ＋役職」の形で使い、Part 7 では resign、retire に言い換えられる。自動詞句なので受動態にはしない。',
'q/k':'適切な後任者が見つかったら CEO の職を「退く」という意味なので step down が正解。step up（進み出る）、step in（介入する、代わりを務める）、step out（少し席を外す）は後任者の文脈に合わない。'})
R('02-37', {
'm/0':'役員、経営陣','m/1':'重役',
'exKo':'数名の上級役員が新しい投資家との会議に出席した。',
'col/0/k':'上級役員','col/1/k':'最高経営責任者','col/2/k':'顧客担当責任者',
'der/0/m':'実行する','der/1/m':'実行、遂行',
'tip':'executive は名詞（役員）としても形容詞（経営の、役員の: executive committee）としても使われる。-ive で終わるが名詞の位置に入れる点をついた問題が出る。',
'q/k':'as a sales の後で「営業担当者」という職を表す名詞の位置なので executive が正解。-ive で終わるが、人を表す名詞として使われる。'})
R('02-38', {
'm/0':'業務量','m/1':'作業量',
'exKo':'その部署は増えた業務量に対処するため、アシスタントを2人採用した。',
'col/0/k':'過重な業務量','col/1/k':'業務量をこなす','col/2/k':'業務量を減らす',
'tip':'「heavy workload（過重な業務）」は Part 3 で手助けを頼む理由としてよく出る。a heavy workload のように単数で使う。',
'q/k':'午後のワークショップに参加できなかった理由として「過重な業務量」が適切なので workload が正解。workforce（人員）、workplace（職場）、workstation（作業スペース）は heavy と一緒に理由にならない。'})
R('02-39', {
'm/0':'褒める、称賛する','m/1':'表彰する',
'exKo':'市長は洪水の間の尽力に対してボランティアたちを称賛した。',
'col/0/k':'BのことでAを称賛する','col/1/k':'高く称賛された',
'der/0/m':'称賛、表彰','der/1/m':'称賛に値する',
'tip':'「commend A for B」は praise A for B と同じ構造で、for の後に称賛の理由が来る。形容詞 commendable（称賛に値する）は主に effort、achievement のような名詞を修飾する。',
'q/k':'宿泊客から高い評価を得たことについて客室清掃スタッフを「称賛した」という意味なので commended が正解。形の似た commanded（命令した）、commenced（開始した）、committed（犯した）は意味が合わない。'})
R('02-40', {
'm/0':'離職率','m/1':'（人員の）入れ替わり','m/2':'売上高',
'exKo':'その会社はより良い研修の機会を提供することで従業員の離職率を下げた。',
'col/0/k':'従業員の離職率','col/1/k':'高い離職率','col/2/k':'年間売上高',
'tip':'人事の文脈では「離職率」、イギリス式の財務の文脈では「売上高」を意味する。「high/low turnover rate」の形が Part 7 によく出る。',
'q/k':'従業員に学生が多く「離職」が多いという意味なので turnover が正解。takeover（買収）、overturn（転覆）、turnout（参加者数）は意味が合わない。'})
