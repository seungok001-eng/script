T = {}
def R(i, d):
    for k, v in d.items(): T[f'words/#{i}/{k}'] = v
R('03-21', {
'm/0':'事務用品',
'exKo':'Ms. Kim は毎週月曜日に紙やトナーなどの事務用品を注文する。',
'col/0/k':'事務用品を注文する','col/1/k':'事務用品店',
'tip':'Part 1・3 では stationery、paper、printer cartridges などの具体的な品物に言い換えられる。「用品」の意味では supplies は複数形で使う。',
'q/k':'ペンやフォルダーなどの品物は「事務用品」なので office supplies が正解。office hours（勤務時間）、office space（オフィススペース）、office buildings（オフィスビル）は pens and folders の例にならない。'})
R('03-22', {
'm/0':'内線（番号）','m/1':'（期限の）延長','m/2':'拡張',
'exKo':'請求部門には内線214番で連絡できる。',
'col/0/k':'内線番号','col/1/k':'期限の延長','col/2/k':'延長を求める',
'der/0/m':'延長する、拡張する','der/1/m':'広範囲にわたる、大規模な',
'tip':'電話の文脈では「内線番号」、締め切りの文脈では「期限の延長」を意味する。形容詞 extensive（広範囲にわたる）と extended（延長された）の区別もよく問われる。',
'q/k':'冠詞 a と two-week の後で requested の目的語となる名詞の位置なので extension が正解。extensive と extended は形容詞なので、後ろに修飾する名詞が必要だ。'})
R('03-23', {
'm/0':'添付する','m/1':'取り付ける',
'exKo':'Ms. Lopez は部長宛てのEメールに売上の数字を添付した。',
'col/0/k':'AをBに添付する','col/1/k':'添付ファイル','col/2/k':'添付の〜をご確認ください',
'der/0/m':'添付ファイル','der/1/m':'添付された',
'tip':'「attach A to B」の前置詞 to がポイントで、Eメールの決まり文句「Please find attached ~」と「the attached file」が Part 6・7 によく出る。',
'q/k':'定冠詞 the と名詞 document の間の形容詞の位置で、文書は「添付された」ものなので過去分詞 attached が正解。attachment は名詞なので document を修飾しない。'})
R('03-24', {
'm/0':'（メールなどを）転送する','m/1':'送る',
'exKo':'Mr. Dunn は顧客の苦情を品質管理チームに転送した。',
'col/0/k':'AをBに転送する','col/1/k':'Eメールを転送する','col/2/k':'（郵便物の）転送先住所',
'tip':'動詞 forward は「forward A to B」の構造で Eメールの文書によく出る。「look forward to ＋ -ing」の to が前置詞である点もあわせて出題される。',
'q/k':'Ms. Allen 宛ての電話をアシスタントに「回して」ほしいという意味なので、「forward A to B」の forward が正解。reply は自動詞で、receive と answer は to her assistant と合わない。'})
R('03-25', {
'm/0':'通信文、手紙','m/1':'（手紙の）やり取り',
'exKo':'顧客とやり取りしたすべての通信文は共有フォルダーに保存しなければならない。',
'col/0/k':'ビジネス文書','col/1/k':'〜との文通',
'der/0/m':'文通する、一致する','der/1/m':'特派員、通信員',
'tip':'不可算名詞なので correspondences や a correspondence とはしない。動詞 correspond は「correspond with（〜と文通する）」「correspond to（〜と一致する）」の形で使う。',
'q/k':'all の後で動名詞 handling の目的語となる名詞の位置で、「海外のサプライヤーからの通信文」という意味なので不可算名詞 correspondence が正解。correspondent は可算名詞（特派員）なので all の後に単数形では来られない。'})
R('03-26', {
'm/0':'緊急の','m/1':'差し迫った',
'exKo':'Mr. Bell は Ms. Cruz にすぐ折り返し電話をくれるよう求める緊急のメッセージを残した。',
'col/0/k':'緊急の案件','col/1/k':'緊急の依頼','col/2/k':'〜を緊急に必要としている',
'der/0/m':'緊急性','der/1/m':'緊急に',
'tip':'副詞 urgently (urgently needed) と名詞 urgency (a sense of urgency) の品詞の位置を問う問題がよく出る。Part 3 では急がなければならない理由の根拠として使われる。',
'q/k':'冠詞 an と名詞 problem の間の形容詞の位置なので urgent が正解。urgently は副詞、urgency と urge は名詞・動詞なので名詞を修飾できない。'})
R('03-27', {
'm/0':'優先事項','m/1':'優先順位',
'exKo':'顧客満足度の向上が今年の会社の最優先課題だ。',
'col/0/k':'最優先事項','col/1/k':'高い優先順位','col/2/k':'〜を優先する',
'der/0/m':'優先順位をつける','der/1/m':'前の、優先する',
'tip':'「top/first priority」「give priority to ＋名詞」が代表的なコロケーションだ。「priority mail（速達郵便）」のように名詞の前で形容詞のようにも使われる。',
'q/k':'所有格 our と形容詞 highest の後の名詞の位置なので priority が正解。prior は形容詞、prioritize は動詞、prioritized は分詞だ。'})
R('03-28', {
'm/0':'優先順位をつける','m/1':'優先的に処理する',
'exKo':'Ms. Ward は新人スタッフに日々の業務の優先順位のつけ方を教えた。',
'col/0/k':'業務に優先順位をつける','col/1/k':'安全を最優先する',
'der/0/m':'優先事項、優先順位','der/1/m':'優先順位づけ',
'tip':'求人広告の「ability to prioritize tasks（業務に優先順位をつける能力）」が頻出だ。名詞 priority と動詞 prioritize の品詞の区別が出題される。',
'q/k':'助動詞 should の後の動詞の原形の位置で、目的語 orders をとるので prioritize が正解。priority と priorities は名詞、prior は形容詞だ。'})
R('03-29', {
'm/0':'効率的な','m/1':'有能な',
'exKo':'新しい書類整理システムは以前のものよりはるかに効率的だ。',
'col/0/k':'エネルギー効率の高い','col/1/k':'〜の効率的な使用','col/2/k':'費用対効果の高い',
'der/0/m':'効率（性）','der/1/m':'効率的に',
'tip':'effective（効果的な）と意味を区別すること。副詞 efficiently と名詞 efficiency の品詞の位置を問う問題がよく出題される。',
'q/k':'more と一緒に名詞 way を修飾する形容詞の位置なので efficient が正解。efficiently は副詞なので名詞を修飾できず、efficiency (-ies) は名詞だ。'})
R('03-30', {
'm/0':'生産性',
'exKo':'新しいソフトウェアは経理部の生産性向上に役立っている。',
'col/0/k':'生産性を高める','col/1/k':'生産性を押し上げる','col/2/k':'従業員の生産性',
'der/0/m':'生産的な','der/1/m':'生産する','der/2/m':'生産、製作',
'tip':'product（製品）、production（生産）、productivity（生産性）、productive（生産的な）の品詞と意味を区別する問題がよく出る。',
'q/k':'動詞 improve の目的語となる名詞の位置で、「従業員の生産性」という意味なので productivity が正解。productive は形容詞、productively は副詞で、名詞 produce は「農産物」なので意味が合わない。'})
R('03-31', {
'm/0':'協力する','m/1':'共同で作業する',
'exKo':'2社は新しい電動自転車のデザインで協力した。',
'col/0/k':'〜と協力する','col/1/k':'〜について協働する','col/2/k':'緊密に協力する',
'der/0/m':'協力、共同作業','der/1/m':'協力的な、共同の',
'tip':'自動詞なので「collaborate with ＋人」「collaborate on ＋プロジェクト」の形で使う。「in collaboration with（〜と協力して）」も頻出だ。',
'q/k':'助動詞 will の後の動詞の原形の位置なので collaborate が正解。collaboration は名詞、collaborative は形容詞、collaboratively は副詞だ。'})
R('03-32', {
'm/0':'調整する、取りまとめる','m/1':'（業務・行事を）統括する',
'exKo':'Ms. Ruiz は訪問するすべての顧客の出張手配を取りまとめている。',
'col/0/k':'〜と調整する','col/1/k':'取り組みを調整する','col/2/k':'日程を調整する',
'der/0/m':'調整、連携','der/1/m':'進行責任者、コーディネーター',
'tip':'人を表す名詞 coordinator（行事の進行責任者）が Part 4・7 によく出る。「coordinate with ＋部署・人」の形も覚えておくこと。',
'q/k':'目的語 the logistics を直接とって「物流業務を取りまとめる」という意味になる必要があるので、他動詞 coordinate が正解。cooperate、collaborate、correspond は自動詞なので前置詞なしで目的語をとれない。'})
R('03-33', {
'm/0':'監督する','m/1':'統括する',
'exKo':'Mr. Chang がホテルのロビー改装工事を監督する。',
'col/0/k':'プロジェクトを監督する','col/1/k':'業務を統括する',
'der/0/m':'監督者','der/1/m':'監督、見落とし（ミス）',
'tip':'過去形 oversaw、過去分詞 overseen という不規則変化に注意すること。名詞 oversight は「監督」と「見落とし（ミス）」という異なる意味を持つ。',
'q/k':'since 2019 とともに現在完了 (has ＋過去分詞) を作る必要があるので、過去分詞 overseen が正解。oversaw は過去形なので has の後には来ない。'})
R('03-34', {
'm/0':'（業務・権限を）委任する、任せる',
'exKo':'優れた管理職は企画に集中できるよう、日常的な業務を部下に任せる。',
'col/0/k':'AをBに任せる','col/1/k':'権限を委譲する',
'der/0/m':'委任、代表団',
'tip':'名詞では「（会議の）代表、参加者」という意味で Part 4・7 の会議関連の文書によく出る。「delegate A to B」の構造を覚えておくこと。',
'q/k':'休暇に出る前に日常業務をアシスタントに「任せた」という意味なので delegated が正解。deleted（削除した）、delayed（遅らせた）、delivered（配達した）は意味が合わない。'})
R('03-35', {
'm/0':'日常的な','m/1':'定期的な',
'exKo':'技術者は毎週金曜日にプリンターの定期点検を行う。',
'col/0/k':'定期点検','col/1/k':'日常業務','col/2/k':'日課',
'der/0/m':'日常的に、定期的に',
'tip':'名詞で「日課、決まりきった仕事」という意味もある。お知らせの「routine maintenance（定期点検）」と副詞 routinely の位置を問う問題がよく出る。',
'q/k':'前置詞 for の後で名詞 maintenance を修飾する位置なので routine が正解。routine maintenance は「定期点検」という表現だ。routinely は副詞なので名詞を修飾できない。'})
R('03-36', {
'm/0':'事務手続き、書類仕事','m/1':'（記入する）書類',
'exKo':'新入社員は初出勤の前にいくつかの書類を記入しなければならない。',
'col/0/k':'書類手続きを済ませる','col/1/k':'書類に記入する',
'tip':'不可算名詞なので paperworks や a paperwork とはしない。Part 3 では forms、documents に言い換えられることが多い。',
'q/k':'予約の前に早めに来て「記入する (fill out)」必要があるのは書類なので paperwork が正解。network（ネットワーク）、framework（枠組み）、artwork（美術品）は fill out の目的語にならない。'})
R('03-37', {
'm/0':'予定より遅れて','m/1':'スケジュールが遅れている',
'exKo':'新しい立体駐車場の工事は予定より2週間遅れている。',
'col/0/k':'予定より遅れる','col/1/k':'予定より早く','col/2/k':'予定どおりに',
'tip':'「ahead of schedule（予定より早く）」「on schedule（予定どおりに）」と一緒に出題される。Part 3・4 では delayed に言い換えられることが多い。',
'q/k':'いくつかの配送品が遅れて届いたので、プロジェクトが「予定より遅れて」いるという意味の behind schedule が正解。ahead は of が必要で意味も逆であり、after と below は schedule とこの意味では使われない。'})
R('03-38', {
'm/0':'残業、時間外労働','m/1':'残業手当',
'exKo':'数名の従業員が年次報告書を仕上げるために残業した。',
'col/0/k':'残業する','col/1/k':'残業手当','col/2/k':'残業時間',
'tip':'「work overtime」の overtime は副詞のように使われ、前置詞なしで動詞の後に置かれる。「overtime pay（残業手当）」は Part 7 の給与関連の文書によく出る。',
'q/k':'週40時間を超えて働いた従業員が受け取るのは「残業手当」なので overtime が正解。overdue（期限を過ぎた）、overall（全体的な）、overhead（頭上の）は意味が合わない。'})
R('03-39', {
'm/0':'交代勤務（時間）、シフト','m/1':'変化、転換',
'exKo':'Mr. Grady は物流センターで夜勤をしている。',
'col/0/k':'夜勤','col/1/k':'シフトに入る','col/2/k':'シフトを代わる',
'tip':'Part 2・3 では「cover one\'s shift（シフトを代わる）」が頻出だ。動詞 shift は「移す、変える」という意味で使われる。',
'q/k':'家族の行事で土曜日に勤務できない Ms. Lee の「シフト」を代わってほしいという意味なので shift が正解。つづりの似た shelf（棚）、sheet（1枚の紙）、shape（形）は意味が合わない。'})
R('03-40', {
'm/0':'作業スペース、自分の席','m/1':'業務用コンピューター',
'exKo':'各作業スペースにはコンピューター、電話、高さ調節が可能な椅子が備わっている。',
'col/0/k':'整頓された作業スペース','col/1/k':'共用の作業スペース',
'tip':'Part 1 のオフィスの写真では desk、work area に言い換えられる。「keep your workstation clean」のような社内のお知らせにもよく出る。',
'q/k':'きれいに保ち、不要な書類を片付けておくべき対象は「作業スペース」なので workstations が正解。workforces（人員）、workloads（業務量）、workshops（研修会）は clean と合わない。'})
R('04-01', {
'm/0':'議題、案件','m/1':'（会議の）予定表',
'exKo':'議題の最初の項目は次の四半期のマーケティング予算だ。',
'col/0/k':'議題に上がっている','col/1/k':'議題を決める','col/2/k':'会議の議題',
'tip':'「on the agenda」（議題に上がっている）のように前置詞 on と一緒に使われ、Part 3・4 で「次の議題は何か」を問う問題の手がかりになる。',
'q/k':'金曜日の会議で扱う「話題 (topics)」を追加する対象は議題のリストである agenda だ。attendance（出席）、venue（会場）、signature（署名）は話題を追加する対象ではない。'})
