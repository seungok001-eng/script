T = {}
def R(i, d):
    for k, v in d.items(): T[f'words/#{i}/{k}'] = v
R('02-01', {
'm/0':'昇進させる','m/1':'宣伝する、販売促進する','m/2':'促進する',
'exKo':'Ms. Garcia はその雑誌社に入社してわずか2年で上級編集者に昇進した。',
'col/0/k':'〜に昇進する','col/1/k':'製品を宣伝する','col/2/k':'販売を促進する',
'der/0/m':'昇進、宣伝、販売促進','der/1/m':'宣伝用の、販促の',
'tip':'「昇進する」は受動形「be promoted to ＋職名」で表す。「宣伝する」の意味も頻出で、形容詞 promotional は「promotional materials（販促物）」の形でよく出る。',
'q/k':'新しいスポーツウェアのラインを「宣伝する」ために動画を作ったという意味なので promote が正解。inform と notify は人を目的語にとり、appoint（任命する）は意味が合わない。'})
R('02-02', {
'm/0':'昇進','m/1':'宣伝、販売促進','m/2':'販促キャンペーン',
'exKo':'Mr. Evans は先月、地域本部長に昇進した。',
'col/0/k':'昇進する','col/1/k':'〜への昇進','col/2/k':'販売促進キャンペーン',
'der/0/m':'昇進させる、宣伝する','der/1/m':'宣伝用の、販促の',
'tip':'「promotion to ＋職名」のように前置詞 to と一緒に使う。店舗のお知らせでは「販促キャンペーン (special promotion)」の意味で Part 4 によく出る。',
'q/k':'前置詞 for の後の名詞の位置なので promotion が正解。promotional は形容詞、promote と promoted は動詞の形なので前置詞の目的語にはなれない。'})
R('02-03', {
'm/0':'転勤する、転勤させる','m/1':'移す、振り込む','m/2':'乗り換える',
'exKo':'Mr. Patel は9月に東京支社へ転勤する。',
'col/0/k':'〜へ転勤する','col/1/k':'AをBに移す（転勤させる）','col/2/k':'電話を転送する',
'der/0/m':'譲渡可能な、移転できる',
'tip':'動詞と名詞が同じ形で (request a transfer)、「transfer to ＋場所」という前置詞の組み合わせがポイントだ。Part 2・3 では「電話をつなぐ」「乗り換える」の意味でも出る。',
'q/k':'家族の近くにいるためにバンクーバー支店へ「転勤させてもらう」ことを願い出たので transferred が正解。transformed（変形された）、translated（翻訳された）、transmitted（送信された）は意味が合わない。'})
R('02-04', {
'm/0':'引退する','m/1':'退職する',
'exKo':'Dr. Simmons はその病院で30年間勤務した後、引退する予定だ。',
'col/0/k':'〜から引退する','col/1/k':'早期退職する',
'der/0/m':'引退、退職','der/1/m':'退職者','der/2/m':'引退した',
'tip':'自動詞なので「retire from ＋会社・役職」の形で使う。名詞 retirement は「retirement party（退職記念パーティー）」「retirement plan（退職年金制度）」の形でよく出る。',
'q/k':'関係代名詞 who の後の動詞の位置で、last year があるので過去形 retired が正解。retirement と retiree は名詞で、retiring は動詞として働くには be動詞が必要だ。'})
R('02-05', {
'm/0':'辞任する','m/1':'辞職する',
'exKo':'最高財務責任者が先週突然辞任した。',
'col/0/k':'〜を辞任する','col/1/k':'〜の職を退く',
'der/0/m':'辞任、辞表',
'tip':'「resign from ＋役職・会社」「resign as ＋職名」の形で使う。名詞 resignation は「submit one\'s resignation（辞表を提出する）」の形で頻出だ。',
'q/k':'主語 Mr. Okoro の後の動詞の位置で、last month があるので過去形 resigned が正解。resignation は名詞で、resigning と to resign は文の動詞にはなれない。'})
R('02-06', {
'm/0':'後任者','m/1':'後継者',
'exKo':'取締役会はまだ退任する CEO の後任者を指名していない。',
'col/0/k':'〜の後任者','col/1/k':'後任者を指名する',
'der/0/m':'後を継ぐ、成功する','der/1/m':'継承、連続',
'tip':'「successor to ＋人・役職」のように前置詞 to を使う。反意語 predecessor（前任者）と対で出題され、動詞 succeed には「後を継ぐ」という意味もある。',
'q/k':'会社を去る前に指導する相手は自分の後を継ぐ「後任者」なので successor が正解。predecessor は「前任者」なので文脈と逆で、success と succession は人ではない。'})
R('02-07', {
'm/0':'〜の後任となる、〜に取って代わる','m/1':'交換する',
'exKo':'Ms. Moreno が Mr. Stein の後任として法務部長を務める。',
'col/0/k':'AをBと交換する','col/1/k':'BとしてAの後任となる',
'der/0/m':'交換（品）、後任者','der/1/m':'交換可能な',
'tip':'「replace A with B（AをBと交換する）」の前置詞 with を問う問題がよく出る。名詞 replacement は「後任者」または「交換品」を意味する。',
'q/k':'「replace A with B（AをBと交換する）」の構文なので replace が正解。repair（修理する）、return（返却する）、remove（取り除く）は with B と組み合わせても「交換する」の意味にならない。'})
R('02-08', {
'm/0':'評価する',
'exKo':'管理職は年末に従業員一人一人の業績を評価する。',
'col/0/k':'業績を評価する','col/1/k':'提案を評価する','col/2/k':'慎重に評価する',
'der/0/m':'評価','der/1/m':'評価者',
'tip':'名詞 evaluation は「performance evaluation（人事考課）」の形でよく出る。to の後の動詞の位置と冠詞の後の名詞の位置を区別する品詞問題に注意すること。',
'q/k':'to不定詞を作る to の後には動詞の原形が来て、目的語 the safety をとるので evaluate が正解。evaluation と evaluator は名詞、evaluative は形容詞だ。'})
R('02-09', {
'm/0':'業績、成果','m/1':'公演','m/2':'性能',
'exKo':'ボーナスは個人の業績と会社の利益に基づいて支給される。',
'col/0/k':'業績評価、人事考課','col/1/k':'職務上の業績','col/2/k':'優れた業績',
'der/0/m':'遂行する、上演する','der/1/m':'演者、遂行者',
'tip':'「業績、成果」の意味では主に不可算名詞として使う。「performance review/evaluation（人事考課）」が頻出で、Part 4 では「公演」の意味で出る。',
'q/k':'所有格と形容詞の後の名詞の位置で、「今年の優れた業績」という意味なので performance が正解。performer は人を表す名詞なので、Ms. Bauer\'s performer では意味が通らない。'})
R('02-10', {
'm/0':'（人事）評価','m/1':'査定、見積もり',
'exKo':'全スタッフが毎年、上司との評価面談を受ける。',
'col/0/k':'人事考課','col/1/k':'年次評価','col/2/k':'不動産鑑定',
'der/0/m':'評価する、査定する','der/1/m':'鑑定士、評価者',
'tip':'performance appraisal は performance evaluation、performance review と言い換えられる。動詞 appraise を apprise（知らせる）と混同しないこと。',
'q/k':'従業員の長所と改善点を把握するために年2回実施するのは「人事考課」なので appraisals が正解。approvals（承認）、applause（拍手）、appliances（家電製品）は意味が合わない。'})
R('02-11', {
'm/0':'傑出した、優れた','m/1':'未払いの、未解決の',
'exKo':'Ms. Cho は顧客への卓越したサービスが評価され、賞を受けた。',
'col/0/k':'優れた業績','col/1/k':'未払い残高','col/2/k':'未解決の問題',
'tip':'「優れた」のほか「未払いの (outstanding balance/payment)」という意味が Part 7 の請求書の文書によく出て、unpaid、overdue に言い換えられる。',
'q/k':'延滞料を避けるには「未払いの」残高を支払う必要があるので outstanding が正解。outgoing（外向的な、出ていく）、outdated（時代遅れの）、outlying（へんぴな）は balance と合わない。'})
R('02-12', {
'm/0':'献身的な','m/1':'専用の',
'exKo':'Mr. Silva はチームを手伝うためによく遅くまで残る献身的な社員だ。',
'col/0/k':'〜に献身している','col/1/k':'献身的なスタッフ','col/2/k':'専用回線',
'der/0/m':'捧げる、献身する','der/1/m':'献身',
'tip':'「be dedicated to ＋名詞・動名詞」の to は前置詞なので、動詞の原形ではなく -ing が続く。「専用の (a dedicated parking area)」という意味も出る。',
'q/k':'空所の後の to providing（前置詞 to ＋動名詞）と結びつくのは「be dedicated to -ing」なので dedicated が正解。eager、willing、able は to の後に動詞の原形が来る。'})
R('02-13', {
'm/0':'（功績を）認める、表彰する','m/1':'見分ける、認識する',
'exKo':'会社は Ms. Ito の10年間の勤続を表彰した。',
'col/0/k':'BのことでAを表彰する','col/1/k':'〜として認められる','col/2/k':'広く認められた',
'der/0/m':'評価、表彰','der/1/m':'見分けのつく',
'tip':'「recognize A for B（Bの功績でAを表彰する）」の構文が授賞式の文書によく出る。「be recognized as（〜として認められる）」も一緒に覚えておくこと。',
'q/k':'年次祝賀会で合併への貢献を称えて従業員を「表彰した」という意味なので recognized が正解。realized（気づいた）、reminded（思い出させた）、remarked（述べた）は「A for B」の構造と意味上合わない。'})
R('02-14', {
'm/0':'評価、表彰','m/1':'認識、見分けること',
'exKo':'Mr. Grant は革新的なデザインが評価されて賞を受けた。',
'col/0/k':'〜を評価して、〜を称えて','col/1/k':'評価を受ける','col/2/k':'ブランド認知度',
'der/0/m':'認める、見分ける','der/1/m':'見分けのつく',
'tip':'「in recognition of（〜を評価して、〜の功績を称えて）」は表彰関連の Part 5・6 の定番表現だ。「brand recognition」は「ブランド認知度」を意味する。',
'q/k':'前置詞 in の後の名詞の位置で、「in recognition of（〜を称えて）」は決まった表現なので recognition が正解。'})
R('02-15', {
'm/0':'報いる','m/1':'報酬を与える',
'exKo':'その会社は成績上位の営業スタッフに全額会社負担の旅行で報いている。',
'col/0/k':'AにBで報いる','col/1/k':'BのことでAに報いる','col/2/k':'特典（ポイント）プログラム',
'der/0/m':'やりがいのある',
'tip':'「reward A for B（理由）/ reward A with B（報酬の手段）」の前置詞の区別がポイントだ。形容詞 rewarding は「やりがいのある (a rewarding career)」という意味なので、「報われる」と勘違いしないこと。',
'q/k':'従業員は現金のボーナスで「報われる」側なので、will be の後で受動態を作る過去分詞 rewarded が正解。rewarding は「やりがいのある」という形容詞で with と合わない。'})
R('02-16', {
'm/0':'奨励策、インセンティブ','m/1':'動機',
'exKo':'その会社は販売目標を達成した従業員に報奨金を支給している。',
'col/0/k':'金銭的な奨励策','col/1/k':'〜する動機','col/2/k':'奨励制度',
'der/0/m':'奨励する、動機づける',
'tip':'「an incentive to do」「an incentive for ＋対象」の形で使い、可算名詞だ。Part 7 では bonus、reward に言い換えられる。',
'q/k':'相乗りを奨励するために企業に与えるのは税の「優遇措置（奨励策）」なので incentives が正解。inventories（在庫）、instances（事例）、intentions（意図）は意味が合わない。'})
R('02-17', {
'm/0':'昇給','m/1':'引き上げ、増加',
'exKo':'Ms. Jung は追加の業務を引き受けた後、上司に昇給を求めた。',
'col/0/k':'昇給する','col/1/k':'昇給','col/2/k':'昇給を求める',
'tip':'名詞 raise は「昇給」として Part 3 によく出る。動詞 raise（他動詞、〜を上げる）と rise（自動詞、上がる）の区別は Part 5 の定番問題だ。',
'q/k':'優れた販売実績のおかげで得たものは「昇給」なので名詞 raise が正解。refund（返金）、receipt（領収書）、reduction（減少）は実績への見返りにならない。'})
R('02-18', {
'm/0':'実力、功績','m/1':'長所、価値',
'exKo':'当社の昇進は年功序列ではなく実力に基づいて行われる。',
'col/0/k':'実力に基づいて','col/1/k':'成果給','col/2/k':'〜の長所',
'tip':'「based on merit（実力に基づいて）」「merit-based pay（成果給）」が人事の文脈の重要表現だ。「the merits of（〜の長所）」の形で提案書の文書にも出る。',
'q/k':'勤続年数 (length of service) と対比される基準なので、「実力、功績」を意味する merit が正解。seniority、tenure、duration はいずれも勤続年数と同じ意味なので rather than の前には来ない。'})
R('02-19', {
'm/0':'（功績を）認める','m/1':'（受け取ったことを）知らせる','m/2':'感謝を表す',
'exKo':'部長はプロジェクトに貢献した全員の努力を称えた。',
'col/0/k':'〜の受領を確認する（知らせる）','col/1/k':'〜の貢献を認める',
'der/0/m':'承認、受領確認','der/1/m':'認められた',
'tip':'「acknowledge receipt of（〜を受け取ったことを知らせる）」は Eメール・手紙の文書の頻出表現だ。他動詞なので直後に目的語や that 節が来る。',
'q/k':'「acknowledge receipt of（〜の受領を確認する）」は決まった表現なので acknowledge が正解。recognize、admit、appreciate は receipt と結びついても受領確認の意味にならない。'})
R('02-20', {
'm/0':'貢献、寄与','m/1':'寄付（金）',
'exKo':'その賞は会社の成長に対する Mr. Ross の貢献を称えるものだ。',
'col/0/k':'〜に貢献する','col/1/k':'多大な貢献','col/2/k':'慈善寄付金',
'der/0/m':'貢献する、寄付する','der/1/m':'貢献者、寄稿者',
'tip':'「contribution to ＋名詞」と「contribute to ＋名詞・動名詞」の前置詞 to がポイントだ。「寄付金」の意味でも使われる。',
'mq/k':'所有格 her と形容詞 significant の後の名詞の位置で、「再生可能エネルギー分野への貢献」という意味なので contribution が正解。contributor は人を表す名詞なので意味が合わない。'})
