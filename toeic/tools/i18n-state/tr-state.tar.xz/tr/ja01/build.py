import json, importlib.util, glob, re
out = {}
for f in sorted(glob.glob('ja01/b*.py')):
    if f.endswith('build.py'): continue
    spec = importlib.util.spec_from_file_location('m', f); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    for k in m.T:
        if k in out: print('dup', k)
    out.update(m.T)
def fix(s):
    # English expressions in ASCII single quotes (keeps checker's verbatim match)
    s = re.sub(r"「([A-Za-z~(][^「」]*)」", r"'\1'", s)
    s = re.sub(r"'(、)?'", "', '", s)
    s = re.sub(r"([A-Za-z0-9')])、\s?(?=[A-Za-z'])", r"\1, ", s)
    return s
out = {k: fix(v) for k, v in out.items()}
json.dump(out, open('out/ja/d-01.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print(len(out))
# restore no-space "word(word" spacing from the Korean source
src = json.load(open('src/d-01.json'))
n = 0
for r in src:
    for k, ko in r['keys'].items():
        t = out[k]
        for a, b in re.findall(r"([A-Za-z'])\(([A-Za-z])", ko):
            t2 = re.sub(re.escape(a) + r" \(" + re.escape(b), a + '(' + b, t)
            if t2 != t: n += 1; t = t2
        out[k] = t
json.dump(out, open('out/ja/d-01.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
print('paren fixes', n)
# spacing around ASCII quotes that sit next to Japanese text
CJK = re.compile(r'[぀-ヿ一-鿿＋〜]')
def qspace(s):
    res = []; state = False; n = len(s)
    for i, ch in enumerate(s):
        if ch == "'" and not (i > 0 and i + 1 < n and s[i-1].isascii() and s[i-1].isalpha() and s[i+1].isascii() and s[i+1].isalpha()):
            if not state:
                if i > 0 and CJK.match(s[i-1]): res.append(' ')
                res.append(ch); state = True; continue
            else:
                res.append(ch); state = False
                if i + 1 < n and CJK.match(s[i+1]): res.append(' ')
                continue
        res.append(ch)
    return ''.join(res), state
bad = []
for k in out:
    t, st = qspace(out[k])
    if st: bad.append(k)
    else: out[k] = t
print('unbalanced', bad)
json.dump(out, open('out/ja/d-01.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=0)
