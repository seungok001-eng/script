import json,sys
d=json.load(open('src/d-01.json'))
a,b=int(sys.argv[1]),int(sys.argv[2])
for r in d[a:b]:
    c=r['ctx']
    print('==',r['root'],c.get('w'),c.get('pos'),'|ex:',c.get('ex'))
    if 'col' in c: print('  col:',[x['e'] for x in c['col']])
    if 'der' in c: print('  der:',[x['w']+'('+x['pos']+')' for x in c['der']])
    if 'q' in c: print('  q:',c['q']['s'],c['q']['o'])
    if 'mq' in c: print('  mq:',json.dumps(c['mq'],ensure_ascii=False))
    for k,v in r['keys'].items(): print('  ',k.split('/',2)[2],'=',v)
