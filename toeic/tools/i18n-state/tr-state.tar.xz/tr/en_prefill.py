# 영어 화면에서는 영어 원문의 '번역'이 필요 없다 → 해당 키를 영어 원문으로 채우고(out/en/_prefill.json),
# 번역가에게는 나머지 키만 준다(src-en/<chunk>.json). 앱은 영어일 때 해석 표시를 숨긴다.
import json, glob, os, re
HERE = os.path.dirname(os.path.abspath(__file__))
os.makedirs(f'{HERE}/src-en', exist_ok=True)
roots = {}
def load_js(p):
    s = open(p, encoding='utf-8').read(); return json.loads(s[s.index('{'):s.rindex('}') + 1])
roots['d'] = load_js('/home/user/script/toeic/app/js/data.js')
roots['p'] = json.load(open(f'{HERE}/practice-all.json', encoding='utf-8'))
def get(o, segs):
    for g in segs:
        if o is None: return None
        if g.startswith('#') and isinstance(o, list): o = next((x for x in o if isinstance(x, dict) and str(x.get('id')) == g[1:]), None)
        elif isinstance(o, list): o = o[int(g)] if g.isdigit() and int(g) < len(o) else None
        else: o = o.get(g) if isinstance(o, dict) else None
    return o
strip = lambda s: s.replace('*', '') if isinstance(s, str) else None
def english(name, key):
    s = key.split('/'); last = s[-1]; par = get(roots[name], s[:-1])
    if last == 'exKo': return strip(par.get('ex')) if isinstance(par, dict) else None
    if last == 'qko': return par.get('q') if isinstance(par, dict) else None
    if len(s) >= 2 and s[-2] == 'col' : return None
    if len(s) >= 3 and s[-3] == 'col' and last == 'k':
        return get(roots[name], s[:-1] + ['e'])
    if last == 'k' and s[0] in ('lc', 'part1') and len(s) == 3:
        return strip(par.get('e')) if isinstance(par, dict) else None
    if len(s) >= 2 and s[-2] in ('xk', 'ok') and last.isdigit():
        sib = get(roots[name], s[:-2] + [{'xk': 'x', 'ok': 'o'}[s[-2]], last]); return sib
    if last == 'ko' and len(s) >= 3 and s[-3] == 'lines':
        return get(roots[name], s[:-1] + ['en'])
    if len(s) >= 2 and s[-2] == 'ko' and last.isdigit():
        base = get(roots[name], s[:-2])
        if isinstance(base, dict):
            if 'paras' in base: v = (base['paras'] + [None] * 99)[int(last)]; return v
            if 'o' in base: return (base['o'] + [None] * 99)[int(last)]
    return None
pre = {}; tot = 0
for f in sorted(glob.glob(f'{HERE}/src/*.json')):
    name = os.path.basename(f)[0]
    recs = json.load(open(f, encoding='utf-8')); out = []
    for r in recs:
        keep = {}
        for k, v in r['keys'].items():
            e = english(name, k)
            if isinstance(e, str) and e.strip(): pre[k] = e
            else: keep[k] = v
        tot += len(r['keys'])
        if keep: out.append({**r, 'keys': keep})
    json.dump(out, open(f'{HERE}/src-en/{os.path.basename(f)}', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
os.makedirs(f'{HERE}/out/en', exist_ok=True)
json.dump(pre, open(f'{HERE}/out/en/_prefill.json', 'w', encoding='utf-8'), ensure_ascii=False)
print('prefilled', len(pre), 'of', tot)
