// 번역 묶음 만들기: src.ko.json 의 d·p 키를 '레코드'(단어 하나, 세트 하나…) 단위로 묶고, 레코드 원본(영어 포함)을 문맥으로 붙인다.
// 결과: src/<d|p>-NN.json = [{ root, ctx, keys: { "<전체 키>": "<한국어>" } }, ...]   (한 묶음 ≈ LIMIT 자)
import fs from "fs"; import path from "path";
const TOEIC = "/home/user/script/toeic", HERE = path.dirname(new URL(import.meta.url).pathname);
const LIMIT = +(process.env.LIMIT || 40000);
const src = JSON.parse(fs.readFileSync(`${TOEIC}/data/i18n/src.ko.json`, "utf8"));
const readJs = (f) => { const s = fs.readFileSync(f, "utf8"); return JSON.parse(s.slice(s.indexOf("{"), s.lastIndexOf("}") + 1)); };
const roots = { d: readJs(`${TOEIC}/app/js/data.js`), p: JSON.parse(fs.readFileSync(`${HERE}/practice-all.json`, "utf8")) };
const get = (o, segs) => { for (const g of segs) { if (o == null) return; o = g[0] === "#" && Array.isArray(o) ? o.find((x) => x && String(x.id) === g.slice(1)) : o[g]; } return o; };
// 문맥에서 빼는 것: 음성·이미지 메타
const STRIP = new Set(["au", "vo", "img", "fm", "ev", "a", "lv", "mock", "src"]);
// 한국어 원문은 keys 에 따로 있으므로 문맥에서는 "@" 로 줄인다 (영어·구조만 남김)
const H = /[\uAC00-\uD7A3]/;
const clean = (x) => typeof x === "string" ? (H.test(x) ? "@" : x) : Array.isArray(x) ? x.map(clean) : x && typeof x === "object" ? Object.fromEntries(Object.entries(x).filter(([k]) => !STRIP.has(k)).map(([k, v]) => [k, clean(v)])) : x;
for (const name of ["d", "p"]) {
  const recs = new Map();
  for (const [k, v] of Object.entries(src[name])) {
    const segs = k.split("/");
    let r = segs.findLastIndex((g) => g[0] === "#");
    // 깊은 하위 id(문항 id 등) 대신 세트 단위로: full/#f6/p3/#fm6-p3-01 처럼 둘째 # 까지
    const hashes = segs.map((g, i) => (g[0] === "#" ? i : -1)).filter((i) => i >= 0);
    if (name === "p" && hashes.length >= 2 && segs[0] === "full" || segs[0] === "half") r = hashes[1] ?? r;
    else if (hashes.length) r = hashes[0];
    const root = r >= 0 ? segs.slice(0, r + 1).join("/") : segs.slice(0, 2).join("/");
    if (!recs.has(root)) recs.set(root, { root, keys: {} });
    recs.get(root).keys[k] = v;
  }
  let chunk = [], size = 0, n = 0;
  const flush = () => { if (!chunk.length) return; n++; fs.writeFileSync(`${HERE}/src/${name}-${String(n).padStart(2, "0")}.json`, JSON.stringify(chunk, null, 1)); chunk = []; size = 0; };
  for (const rec of recs.values()) {
    const ctx = clean(get(roots[name], rec.root.split("/")));
    const sz = Object.values(rec.keys).reduce((a, s) => a + s.length, 0);
    if (size + sz > LIMIT && chunk.length) flush();
    chunk.push({ root: rec.root, ctx, keys: rec.keys }); size += sz;
  }
  flush();
  console.log(name, "records", recs.size, "chunks", n);
}
