import json,sys
d=json.load(open('src/d-01.json'))
a,b=int(sys.argv[1]),int(sys.argv[2])
for r in d[a:b]:
    c=r['ctx'];p=r['root']+'/'
    print('##',c['w'],c.get('pos'),'| ex:',c.get('ex'))
    if 'col' in c: print('  col:',[x['e'] for x in c['col']])
    if 'der' in c: print('  der:',[x['w']+'('+x.get('pos','')+')' for x in c['der']])
    if 'q' in c: print('  q:',c['q'].get('s'),c['q'].get('o'))
    for k,v in c.items():
        if k not in('id','d','w','pos','m','tier','parts','ex','exKo','col','der','para','tip','q','ipa','exAu','exV','ant'): print('  ',k,':',json.dumps(v,ensure_ascii=False)[:300])
    for k,v in r['keys'].items(): print('  ',k[len(p):],'=',v)
