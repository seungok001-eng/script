import json,importlib.util
d=json.load(open('src/d-01.json'))
out={}
for i in range(1,8):
    spec=importlib.util.spec_from_file_location(f'b{i}',f'es01/b{i}.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    for rid,kv in m.T.items():
        for k,v in kv.items(): out[f'words/#{rid}/{k}']=v
keys=set(k for r in d for k in r['keys'])
print('missing',[k for k in keys if k not in out][:10]); print('extra',[k for k in out if k not in keys][:10])
json.dump({k:out[k] for r in d for k in r['keys'] if k in out},open('out/es/d-01.json','w',encoding='utf-8'),ensure_ascii=False,indent=0)
