# 토익핏 번역 가이드 (Korean → target language)

The app teaches TOEIC (English test). Korean is the original UI/explanation language. You translate the **Korean** text into the
target language for learners whose native language is the target language. **English content (questions, passages, example
sentences, options) is never translated or changed** — only the Korean around it.

## Target languages and voice
| code | language | UI voice | explanations / tips | word meanings |
|---|---|---|---|---|
| en | English | friendly, concise ("you") | clear, plain English | short English gloss or synonym (NOT the headword itself; e.g. applicant → "candidate; person who applies") |
| ja | 日本語 | です・ます | だ・である調 (textbook style), concise | 辞書風の短い訳語 (例: 応募者、志願者) |
| vi | Tiếng Việt | lịch sự, tự nhiên ("bạn") | rõ ràng, ngắn gọn | nghĩa ngắn kiểu từ điển |
| zh-TW | 繁體中文（台灣） | 自然、親切（「你」） | 簡潔清楚的說明 | 字典式簡短譯義；台灣用語（軟體、影片、資訊） |
| es | Español neutro (Latinoamérica) | "tú", natural | claro y breve | glosa breve tipo diccionario |
| fr | Français | « vous » | clair et concis | glose courte de dictionnaire |

## Rules (all strict)
1. **Translate meaning, not Korean form.** Use the English context (`ctx`: headword `w`, example `ex`, collocation `e`, passage `en`/`paras`, question `q`, options `o`) to pick the right sense. Strings shown as `"@"` in ctx are the Korean texts you are translating (listed in `keys`).
2. **Keep every English fragment's words exactly as written** (punctuation between English items may follow target-language style, e.g. 、 or y) inside the Korean: quoted phrases, words, options, `A → B` paraphrase notes, part names (Part 5), letters `(A)`–`(D)`, numbers, prices, times, URLs. Do not translate or re-case them.
3. **People / company / place names**: Korean texts transliterate English names (린드크비스트 씨 = Mr. Lindqvist). Always write the **original English spelling** found in the ctx (titles: Mr./Ms./Dr. in English, or the natural target-language honorific placed correctly — e.g. ja「リンドクヴィストさん」is wrong; write "Mr. Lindqvist" or 「Lindqvistさん」; prefer the English form).
4. Korean grammar terms → the standard term in the target language's English-grammar teaching tradition (e.g. 현재완료 → present perfect / 現在完了 / thì hiện tại hoàn thành / 現在完成式 / pretérito perfecto compuesto (present perfect) / present perfect (passé composé anglais)). When in doubt, add the English term in parentheses.
5. Korean particles attached to letters/words (`(A)를`, `access가`) disappear naturally in translation.
6. Placeholders `{0}`, `{1}` and HTML tags (`<b>…</b>`, `<br>`, `<span …>`) must be kept exactly, same count. You may reorder placeholders to fit grammar.
7. Translation of a passage/conversation (`ko` of lines or paragraphs) must match the English line-for-line, natural in the target language. Sentence-insertion markers `[1]`–`[4]` stay in the same positions.
8. No Korean characters may remain. No added commentary. Keep it as short as the Korean (UI strings must fit small buttons).
9. Korean-specific content (e.g. a tip comparing two Korean words, Korean pronunciation) → rewrite the point so it makes sense for a target-language speaker, keeping the English teaching point.
10. Labels (categories like "Part 2 우회 응답", "사무실", "세부 사항") are short tags: translate consistently; use the same translation every time a term recurs (glossary file if given).

## Output
Write with a Python script (json.dump(..., ensure_ascii=False, indent=0)) to the output path you are given:
`{"<full key>": "<translation>", ...}` with **every** key of every record in your input chunk, nothing else.
Then run the checker: `python3 /tmp/claude-0/-home-user-script/daeb160e-7d1b-5b97-88f4-a9d67a2fe616/scratchpad/tr/check.py <input chunk> <output file> <lang>` and fix until it prints OK.
Finally re-read a sample of ~40 of your translations against the ctx as a strict native reviewer and fix anything unnatural or wrong.
