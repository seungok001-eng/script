"""check.py <ID> [--all] — validates out/<ID>.json against in/<ID>.json, SPEC rules and the duplicate corpus."""
import json, os, re, sys, glob, collections

G = os.path.dirname(os.path.abspath(__file__))
STOP = set("the a an of to in on at for and or by with from is are was were be been will would can could should may this that these those it its their our your his her as all any".split())


def toks(s):
    return [w for w in re.findall(r"[a-z']+", s.lower().replace("-------", " ")) if w not in STOP]


def sim(a, b):
    A, B = set(toks(a)), set(toks(b))
    return len(A & B) / max(1, len(A | B))


def corpus(exclude_id):
    out = [(src, i, s) for src, i, s in json.load(open(os.path.join(G, "corpus.json")))]
    for f in glob.glob(os.path.join(G, "out", "*.json")):
        oid = os.path.basename(f)[:-5]
        if oid == exclude_id: continue
        try:
            for q in json.load(open(f)).get("qs", []): out.append(("new:" + oid, q.get("id"), q.get("s", "")))
        except Exception: pass
    return out


def check(ID):
    errs, warns = [], []
    inp = json.load(open(os.path.join(G, "in", ID + ".json")))
    try:
        o = json.load(open(os.path.join(G, "out", ID + ".json")))
    except Exception as e:
        return [f"out/{ID}.json unreadable: {e}"], []
    qs = o.get("qs", [])
    want = {1: inp["add_count"]["lv1"], 2: inp["add_count"]["lv2"], 3: inp["add_count"]["lv3"]}
    have = collections.Counter(q.get("lv") for q in qs)
    for l in (1, 2, 3):
        if have[l] != want[l]: errs.append(f"lv{l}: {have[l]} questions, need {want[l]}")
    n0 = inp["next_id_number"]
    for k, q in enumerate(qs):
        qid = q.get("id"); exp_id = f"{ID}-{n0 + k:02d}"
        if qid != exp_id: errs.append(f"#{k}: id {qid} should be {exp_id}")
        s = q.get("s", "")
        if s.count("-------") != 1 or "--------" in s: errs.append(f"{qid}: blank must be exactly one '-------'")
        nw = len(re.findall(r"[A-Za-z']+", s))
        if not 10 <= nw <= 34: warns.append(f"{qid}: {nw} words (aim 12-30)")
        opts = q.get("o", [])
        if len(opts) != 4 or len(set(o_.strip().lower() for o_ in opts)) != 4 or any(not o_.strip() for o_ in opts): errs.append(f"{qid}: need 4 distinct non-empty options")
        if q.get("a") not in (0, 1, 2, 3): errs.append(f"{qid}: a must be 0-3")
        e = q.get("exp", "")
        if len(e) < 40 or not re.search(r"[가-힣]", e): errs.append(f"{qid}: exp too short / not Korean")
        elif len(opts) == 4 and q.get("a") in (0, 1, 2, 3) and opts[q["a"]].split()[0].lower() not in e.lower(): warns.append(f"{qid}: exp does not mention the answer '{opts[q['a']]}'")
    pos = collections.Counter(q.get("a") for q in qs)
    if qs and max(pos.values()) > len(qs) * 0.4: warns.append(f"answer positions unbalanced: {dict(pos)}")
    la = o.get("lesson_add", [])
    need_l = 6 if inp.get("basic") else 2
    if len(la) != need_l: errs.append(f"lesson_add: {len(la)} items, need {need_l}")
    for i, l in enumerate(la):
        if not (l.get("h") and l.get("t") and len(l.get("ex", [])) == 2 and all(x.get("en") and x.get("ko") and "*" in x["en"] for x in l["ex"])):
            errs.append(f"lesson_add[{i}]: needs h, t, 2 ex with en (with *mark*) and ko")
    if inp.get("basic") and len(o.get("trap", "")) < 40: errs.append("basic topic needs a trap paragraph")
    # duplicates
    corp = corpus(ID) + [("existing", q["s"][:20], q["s"]) for q in inp["existing_questions"]]
    for i, q in enumerate(qs):
        s = q.get("s", "")
        for src, cid, cs in corp:
            r = sim(s, cs)
            if r >= 0.6: errs.append(f"{q.get('id')}: near-duplicate ({r:.2f}) of {src} {cid}: {cs[:70]}")
            elif r >= 0.45: warns.append(f"{q.get('id')}: similar ({r:.2f}) to {src} {cid}: {cs[:70]}")
        for j in range(i):
            r = sim(s, qs[j].get("s", ""))
            if r >= 0.5: errs.append(f"{q.get('id')}: too similar ({r:.2f}) to {qs[j].get('id')}")
    return errs, warns


if __name__ == "__main__":
    ids = [os.path.basename(f)[:-5] for f in sorted(glob.glob(os.path.join(G, "out", "*.json")))] if "--all" in sys.argv else sys.argv[1:]
    bad = 0
    for ID in ids:
        e, w = check(ID)
        print(f"== {ID}: {'OK' if not e else str(len(e)) + ' errors'}, {len(w)} warnings")
        for x in e[:40]: print("  ERR", x)
        for x in w[:15]: print("  warn", x)
        bad += bool(e)
    sys.exit(1 if bad else 0)
