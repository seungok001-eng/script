"""blind.py make <ID>... : out/<ID>.json -> verify/<ID>.q.json (no keys, no explanations)
   blind.py cmp <ID>...  : compare verify/<ID>.ans.json with keys, print mismatches/flags"""
import json, os, sys
G = os.path.dirname(os.path.abspath(__file__))
cmd, ids = sys.argv[1], sys.argv[2:]
if ids == ["--all"]: ids = sorted(f[:-5] for f in os.listdir(os.path.join(G, "out")))
bad = 0
for ID in ids:
    o = json.load(open(os.path.join(G, "out", ID + ".json")))
    if cmd == "make":
        json.dump([{"id": q["id"], "s": q["s"], "o": q["o"]} for q in o["qs"]], open(os.path.join(G, "verify", ID + ".q.json"), "w"), ensure_ascii=False, indent=0)
        continue
    p = os.path.join(G, "verify", ID + ".ans.json")
    if not os.path.exists(p): print(ID, "no answers"); continue
    ans = json.load(open(p)); n = 0
    for q in o["qs"]:
        r = ans.get(q["id"])
        if r is None: print(f"  {q['id']}: missing"); n += 1; continue
        if r["a"] != q["a"] or r.get("flag"):
            n += 1
            print(f"  {q['id']}: key={q['a']}({q['o'][q['a']]}) solver={r['a']}({q['o'][r['a']] if r['a'] in range(4) else '?'}) flag={r.get('flag','')}\n     {q['s']}\n     {q['o']}")
    print(f"== {ID}: {len(o['qs'])} items, {n} to review"); bad += n
sys.exit(1 if bad else 0)
