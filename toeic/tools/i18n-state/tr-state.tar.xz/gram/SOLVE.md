# Blind solve (independent verification)
You are a top TOEIC instructor and a strict native-English copy editor. You get Part 5 items WITHOUT answer keys:
`verify/<ID>.q.json` = list of {id, s, o}. Do NOT open out/, work/ or any other file except your q files and this spec.

For every item:
1. Solve it cold, as on the real test. Pick the single best option index 0-3.
2. Then check each of the OTHER three options against the sentence as a careful native editor: could it also be
   grammatical AND natural with the intended meaning (American English, business register)? If yes, or if the sentence
   itself has an error/awkwardness, or if no option works, set "flag" to a short English note explaining exactly why.
   Do not flag merely because an item is easy or hard. Flag only real problems (second defensible answer, error, unnatural wording).

Write `verify/<ID>.ans.json` = {"<id>": {"a": <index>, "flag": "<note, omit if none>"}, ...} for every item (use a Python script, json.dump).
Report: per ID the number of items and the list of flagged ids with notes.
