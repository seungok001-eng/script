# TOEIC Part 5 grammar content — writing spec

You write content for a commercial TOEIC study app (Korean learners; explanations in Korean).
Quality bar: indistinguishable from the best published TOEIC grammar books (ETS-style), zero errors.

## Your input
`in/<ID>.json`: the topic (title, category, current lesson items, trap note), every existing question for the topic,
`add_count` (how many NEW questions to write per level) and `next_id_number`.

## Your output
Write `out/<ID>.json` (UTF-8, valid JSON):
```json
{
  "id": "<ID>",
  "lesson_add": [ { "h": "...", "t": "...", "ex": [ {"en": "...", "ko": "..."}, {"en": "...", "ko": "..."} ] } ],
  "trap": "<only for basic topics; otherwise omit>",
  "qs": [ { "id": "<ID>-16", "s": "...", "o": ["...","...","...","..."], "a": 2, "lv": 1, "exp": "..." } ]
}
```
- Question ids continue from `next_id_number`, two digits (`g01-16`, `g01-17`, … `b01-01` …).
- Exactly `add_count.lv1` questions with `"lv": 1`, `add_count.lv2` with `"lv": 2`, `add_count.lv3` with `"lv": 3`.

## Lesson additions (`lesson_add`)
- Regular topics: add **2** new lesson items covering what the current lesson does NOT yet explain well:
  exceptions, commonly confused pairs (a short comparison written in prose, e.g. "A는 …, B는 …"), word-order points,
  or high-frequency TOEIC patterns for this topic. Do not repeat existing points.
- `h`: short heading (Korean, may contain English forms). `t`: 2–4 clear sentences in Korean, same tone as the existing items
  (plain declarative "~다." style). `ex`: exactly 2 TOEIC-style English examples, the key word(s) wrapped in `*asterisks*`,
  with a natural Korean translation in `ko`.
- **Basic topics** (`"basic": true`, empty lesson): write **6** lesson items for complete beginners (400–550 score level):
  define every term the first time it appears (e.g. 품사, 주어, 목적어, 보어, 수식어, 구, 절, 자동사/타동사, 원형·과거·과거분사),
  explain how each concept shows up in Part 5 blanks, and link forward to the regular topics by name (e.g. "→ '명사 자리'에서 자세히").
  Also write a one-paragraph `trap` (Korean) with the most common beginner mistake.

## Questions — hard requirements
1. **Authentic Part 5 format**: one English sentence, 12–30 words, business/workplace context, exactly one blank written as
   `-------` (seven hyphens), four options, `a` = index 0–3 of the correct option.
2. **Exactly one correct answer.** The other three must be clearly wrong *grammatically* (or, for meaning-based grammar such as
   conjunction/preposition choice, clearly wrong in meaning). No option that a careful native editor could also accept.
   Re-read every question as a strict proofreader before you keep it.
3. **Tests this topic's grammar point** (at least 85% of your questions squarely; the rest may test a closely related point
   that the topic's lesson mentions). Not vocabulary-meaning questions.
4. **Options**: real, correctly spelled words/forms of the kind real TOEIC uses for this point (same word family for
   part-of-speech items; tense/voice variants for verb items; conjunction vs preposition vs adverb for connector items, etc.).
   No duplicate options. Keep option order natural (e.g. word-family items listed in a sensible order), and spread the correct
   position evenly: across your set, A/B/C/D should each be the answer about 25% of the time.
5. **Difficulty**:
   - lv1 (쉬움): the deciding clue is right next to the blank; one-step decision.
   - lv2 (보통): needs sentence-structure analysis (finding the subject/verb, clause boundaries) or a less obvious clue.
   - lv3 (어려움): long sentence or inserted phrases, attractive trap options, a clue far from the blank, or a less common
     form (inversion, reduced clause, -ever words, etc.). Still exactly one correct answer.
6. **Variety**: vary contexts (HR, finance, logistics, manufacturing, retail, hospitality, travel, IT, marketing, real estate,
   healthcare admin, events, construction, legal/contracts, customer service), sentence frames, subjects and names
   (international mix: Ms. Okafor, Mr. Lindqvist, Dr. Patel, Ms. Nakamura …). Fictional company names only.
   No two of your questions may share the same sentence frame with only words swapped.
7. **No overlap**: do not reuse or paraphrase any existing question in your input; do not reuse well-known textbook sentences.
   Every sentence must be newly written.
8. **Language**: American English, natural business register, correct punctuation; numbers/times in TOEIC style (3:00 P.M., $250).
   Nothing sensitive (no politics, religion, health conditions, violence, alcohol focus).

## Explanations (`exp`, Korean)
- 2–4 sentences, same style as the existing explanations: first state the clue and why the answer is correct
  ("…이므로 X가 정답이다."), then briefly why the other options fail (part of speech, form, meaning, structure).
- Quote English words exactly as they appear. Use the terminology of the lesson (명사 자리, 수 일치, 능동태 …).
- Must be accurate. If a distractor is wrong for more than one reason, give the most decisive reason.

## Self-check before saving (do it, then fix)
- Count per level matches `add_count`; ids are sequential; every `s` contains `-------` exactly once; `a` points to the right option.
- For every question, solve it yourself cold, as a TOEIC test taker, and confirm only the keyed option works.
- Run: `python3 ../check.py <ID>` from your work folder (or `python3 /tmp/claude-0/-home-user-script/daeb160e-7d1b-5b97-88f4-a9d67a2fe616/scratchpad/gram/check.py <ID>`)
  and fix everything it reports, including near-duplicates against the corpus.

Keep any helper scripts inside `work/<ID>/`. Do not modify any other file.
