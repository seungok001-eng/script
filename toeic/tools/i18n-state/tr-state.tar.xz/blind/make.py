# 정답·해설·해석을 지운 문제지(blind/q-<그룹>.json)와 정답표(blind/key.json)를 만든다
import json, glob, os
FM3 = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'fm3')
L = 'ABCD'
groups = {'p1': ['p1a', 'p1b'], 'p2': ['p2a', 'p2b', 'p2c', 'p2d'], 'p5': ['p5a', 'p5b', 'p5c', 'p5d'],
          'p3': [f'p3{c}' for c in 'abcdefg'], 'p4': [f'p4{c}' for c in 'abcd'], 'p6': ['p6a', 'p6b', 'p6c'],
          'p7s': ['p7sa', 'p7sb', 'p7sc', 'p7sd'], 'p7m': ['p7ma', 'p7mb', 'p7mc']}
key = {}
def opts(o): return [f'({L[i]}) {t}' for i, t in enumerate(o)]
for g, bs in groups.items():
    out = []
    for b in bs:
        for i, it in enumerate(json.load(open(f'{FM3}/out-{b}.json'))['items'], 1):
            sid = f'{b}#{i}'
            if g == 'p1':
                key[sid] = it['a']
                out.append({'id': sid, 'photo_description': it['prompt'], 'options': opts(it['o'])})
            elif g == 'p2':
                key[sid] = it['a']
                out.append({'id': sid, 'question': it['q'], 'responses': opts(it['o'])})
            elif g == 'p5':
                key[sid] = it['a']
                out.append({'id': sid, 'sentence': it['s'], 'options': opts(it['o'])})
            elif g in ('p3', 'p4'):
                qs = []
                for k, q in enumerate(it['qs'], 1):
                    key[f'{sid}.{k}'] = q['a']
                    qs.append({'id': f'{sid}.{k}', 'q': q['q'], 'options': opts(q['o'])})
                o = {'id': sid, 'transcript': [f"{l['sp']}: {l['en']}" for l in it['lines']], 'questions': qs}
                if it.get('graphic'): o['graphic'] = it['graphic']
                out.append(o)
            elif g == 'p6':
                qs = []
                for k, q in enumerate(it['qs'], 1):
                    key[f'{sid}.{k}'] = q['a']
                    qs.append({'id': f'{sid}.{k}', 'blank': q.get('n', k), 'options': opts(q['o'])})
                out.append({'id': sid, 'title': it.get('title', ''), 'paragraphs': it['paras'], 'questions': qs})
            else:
                qs = []
                for k, q in enumerate(it['qs'], 1):
                    key[f'{sid}.{k}'] = q['a']
                    qq = {'id': f'{sid}.{k}', 'q': q['q'], 'options': opts(q['o'])}
                    if q.get('sent'): qq['sentence_to_insert'] = q['sent']
                    qs.append(qq)
                docs = [{k: d[k] for k in ('doc', 'title', 'meta', 'paras', 'graphic') if d.get(k)} for d in it['docs']]
                out.append({'id': sid, 'documents': docs, 'questions': qs})
    size = {'p1': 45, 'p2': 95, 'p5': 115, 'p3': 48, 'p4': 35, 'p6': 30, 'p7s': 35, 'p7m': 15}[g]
    for c in range(0, len(out), size):
        json.dump(out[c:c + size], open(f'blind/q-{g}-{c // size + 1}.json', 'w'), ensure_ascii=False, indent=1)
    print(g, len(out), 'sets/items', '→', (len(out) + size - 1) // size, 'files')
json.dump(key, open('blind/key.json', 'w'))
print('questions', len(key))
