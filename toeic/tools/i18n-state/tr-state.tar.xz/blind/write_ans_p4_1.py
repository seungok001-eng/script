import json
a = {
"p4a#1":"CDA","p4a#2":"BDC","p4a#3":"ACD","p4a#4":"DAB","p4a#5":"CBD","p4a#6":"ADB",
"p4a#7":"BCA","p4a#8":"DAC","p4a#9":"CDB","p4a#10":"ABD","p4a#11":"DCA","p4a#12":"BAC",
"p4a#13":"CDB","p4a#14":"ABD","p4a#15":"DCA","p4a#16":"BAC","p4a#17":"ADB","p4a#18":"CBD",
"p4b#1":"CBC","p4b#2":"AAD","p4b#3":"ACB","p4b#4":"DAB","p4b#5":"BCB","p4b#6":"ABC",
"p4b#7":"CDA","p4b#8":"ADA","p4b#9":"BAC","p4b#10":"DCB","p4b#11":"DBB","p4b#12":"CCD",
"p4b#13":"BCA","p4b#14":"CAD","p4b#15":"CDA","p4b#16":"DAB","p4b#17":"BDB",
}
out = {}
for s, letters in a.items():
    for i, l in enumerate(letters, 1):
        out[f"{s}.{i}"] = {"a": l, "note": ""}
p = "/tmp/claude-0/-home-user-script/daeb160e-7d1b-5b97-88f4-a9d67a2fe616/scratchpad/blind/ans-p4-1.json"
json.dump(out, open(p, "w"), indent=1)
print(len(out))
