# blind/ans-*.json ({"id": "A"|"B"|..., ...} 또는 {"id": {"a": "B", "note": "..."}}) 를 정답표와 비교
import json, glob, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
key = json.load(open('key.json')); L = 'ABCD'
got = {}
for f in glob.glob('ans-*.json'):
    for k, v in json.load(open(f)).items():
        got[k] = v
miss = [k for k in key if k not in got]
wrong = []
for k, v in got.items():
    if k not in key: continue
    a = v['a'] if isinstance(v, dict) else v
    if a is None or a == '?' or L.index(a[0]) != key[k]:
        wrong.append((k, a, L[key[k]], v.get('note', '') if isinstance(v, dict) else ''))
print(f'답 {len(got)}/{len(key)} · 불일치 {len(wrong)} · 미응답 {len(miss)}')
for k, a, ka, n in sorted(wrong): print(f'  {k}: 풀이 {a} / 정답표 {ka}  {n}')
if miss: print('미응답:', miss[:30])
