import json
a = {
"p4b#18.1":"D","p4b#18.2":"A","p4b#18.3":"D",
"p4c#1.1":"B","p4c#1.2":"A","p4c#1.3":"A",
"p4c#2.1":"D","p4c#2.2":"A","p4c#2.3":"B",
"p4c#3.1":"B","p4c#3.2":"B","p4c#3.3":"C",
"p4c#4.1":"C","p4c#4.2":"A","p4c#4.3":"D",
"p4c#5.1":"C","p4c#5.2":"C","p4c#5.3":"D",
"p4c#6.1":"B","p4c#6.2":"D","p4c#6.3":"A",
"p4c#7.1":"C","p4c#7.2":"A","p4c#7.3":"B",
"p4c#8.1":"B","p4c#8.2":"D","p4c#8.3":"B",
"p4c#9.1":"C","p4c#9.2":"A","p4c#9.3":"C",
"p4c#10.1":"A","p4c#10.2":"C","p4c#10.3":"B",
"p4c#11.1":"B","p4c#11.2":"C","p4c#11.3":"C",
"p4c#12.1":"A","p4c#12.2":"C","p4c#12.3":"D",
"p4c#13.1":"C","p4c#13.2":"D","p4c#13.3":"A",
"p4c#14.1":"D","p4c#14.2":"D","p4c#14.3":"B",
"p4c#15.1":"D","p4c#15.2":"B","p4c#15.3":"A",
"p4c#16.1":"B","p4c#16.2":"C","p4c#16.3":"A",
"p4c#17.1":"D","p4c#17.2":"D","p4c#17.3":"A",
"p4d#1.1":"B","p4d#1.2":"D","p4d#1.3":"C",
"p4d#2.1":"D","p4d#2.2":"C","p4d#2.3":"D",
"p4d#3.1":"A","p4d#3.2":"C","p4d#3.3":"B",
"p4d#4.1":"D","p4d#4.2":"A","p4d#4.3":"C",
"p4d#5.1":"C","p4d#5.2":"B","p4d#5.3":"A",
"p4d#6.1":"C","p4d#6.2":"A","p4d#6.3":"D",
"p4d#7.1":"B","p4d#7.2":"A","p4d#7.3":"D",
"p4d#8.1":"B","p4d#8.2":"A","p4d#8.3":"C",
"p4d#9.1":"B","p4d#9.2":"D","p4d#9.3":"A",
"p4d#10.1":"C","p4d#10.2":"A","p4d#10.3":"D",
"p4d#11.1":"B","p4d#11.2":"B","p4d#11.3":"D",
"p4d#12.1":"C","p4d#12.2":"A","p4d#12.3":"B",
"p4d#13.1":"D","p4d#13.2":"B","p4d#13.3":"A",
"p4d#14.1":"D","p4d#14.2":"C","p4d#14.3":"B",
"p4d#15.1":"D","p4d#15.2":"B","p4d#15.3":"A",
"p4d#16.1":"B","p4d#16.2":"C","p4d#16.3":"D",
"p4d#17.1":"A","p4d#17.2":"C","p4d#17.3":"B",
}
notes = {
"p4d#3.2": "Answerable without the graphic by elimination: the talk itself names the visitor-center film (A), the top of the dam (B) and the salmon final stop (D, Fish Ladder), leaving only Generator Hall.",
"p4d#16.2": "Partly guessable without the graphic, since automatic address printing for orders suggests the Warehouse (or Packaging) team even without the table.",
}
out = {k: {"a": v, "note": notes.get(k, "")} for k, v in a.items()}
assert len(out) == 105, len(out)
json.dump(out, open("/tmp/claude-0/-home-user-script/daeb160e-7d1b-5b97-88f4-a9d67a2fe616/scratchpad/blind/ans-p4-2.json", "w"), indent=1)
print(len(out))
