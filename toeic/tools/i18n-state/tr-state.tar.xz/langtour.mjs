const { chromium } = await import("/opt/node22/lib/node_modules/playwright/index.mjs");
const base = "http://localhost:8765/index.html", out = process.argv[2], LANG = process.argv[3];
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: LANG });
await ctx.route("**/js/l10n/langs.js", (r) => r.fulfill({ contentType: "application/javascript", body: `window.TOEICFIT_LANGS=[{"code":"ko","name":"한국어"},{"code":"${LANG}","name":"${LANG}"}];` }));
const p = await ctx.newPage();
const errs = []; p.on("pageerror", (e) => errs.push(e.message)); p.on("console", (m) => { if (m.type() === "error") errs.push(m.text()); });
const leaks = new Map();
async function scan(tag) {
  const txt = await p.evaluate(() => {
    const out = []; const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n; while ((n = w.nextNode())) { const t = n.nodeValue.trim(); if (t && /[가-힣]/.test(t)) out.push(t); }
    document.querySelectorAll("[aria-label],[title],[placeholder]").forEach((e) => ["aria-label", "title", "placeholder"].forEach((a) => { const v = e.getAttribute(a); if (v && /[가-힣]/.test(v)) out.push("@" + a + ":" + v); }));
    return out;
  });
  for (const t of txt) { const k = t; if (/[가-힣]/.test(k)) leaks.set(k.slice(0, 100), tag); }
}
await p.goto(base); await p.waitForTimeout(600); await scan("onb1");
await p.screenshot({ path: out + "-onb.png" });
await p.click("[data-next]"); await scan("onb2"); await p.click('[data-score="700"]'); await p.click("[data-next]"); await scan("onb3"); await p.click("[data-next]"); await scan("onb4"); await p.click("[data-next]");
await p.waitForTimeout(1200); await scan("diag"); await p.click("[data-diag-later]"); await p.waitForTimeout(400);
for (const r of ["#/home", "#/days", "#/day/1", "#/practice", "#/sets/p3", "#/sets/p1", "#/grammar", "#/mock", "#/review", "#/stats", "#/settings", "#/guide", "#/lc", "#/part1", "#/conf", "#/search", "#/premium"]) {
  await p.goto(base + r); await p.waitForTimeout(500); await scan(r);
  if (r === "#/home" || r === "#/practice" || r === "#/settings") await p.screenshot({ path: out + "-" + r.slice(2) + ".png" });
}
await p.goto(base + "#/home"); await p.waitForTimeout(300);
await p.click('.hero [data-go="new"]'); await p.waitForTimeout(400); await scan("card"); await p.click("[data-flip]"); await p.waitForTimeout(200); await scan("card-back");
await p.screenshot({ path: out + "-card.png" });
await p.goto(base + "#/sets/p3"); await p.waitForTimeout(1500); if (!(await p.$("[data-run]"))) { console.log("NO RUN", p.url(), (await p.textContent("#app")).slice(0, 400)); console.log(errs.join("\n").slice(0,1500)); process.exit(0); } await p.click("[data-run]"); await p.waitForTimeout(400); await scan("p3q");
for (let j = 0; j < 3; j++) await p.click(`.pq [data-q="${j}"][data-o="0"]`);
await p.click("[data-grade]"); await p.waitForTimeout(300); await scan("p3graded"); await p.screenshot({ path: out + "-p3g.png", fullPage: true });

// 더 많은 화면: 퀴즈 · 문법 주제 · Part 2 퀴즈 · 모의고사 · 결과
await p.goto(base + "#/home"); await p.waitForTimeout(300);
try { await p.goto(base + "#/grammar"); await p.waitForTimeout(400); const g = await p.$('a.witem'); if (g) { await g.click(); await p.waitForTimeout(400); await scan("grammar-topic"); const st = await p.$('[data-start], [data-gstart]'); if (st) { await st.click(); await p.waitForTimeout(300); await scan("gq"); const o = await p.$('[data-o]'); if (o) { await o.click(); await p.waitForTimeout(300); await scan("gq-ans"); } } } } catch (e) { console.log("grammar", e.message); }
try { await p.goto(base + "#/mock"); await p.waitForTimeout(400); await p.click('[data-mock="1"]'); await p.waitForTimeout(200); await scan("mock-modal"); await p.click("[data-go-mock]"); await p.waitForTimeout(800); await scan("mock-p1");
  for (let k = 0; k < 200 && !(await p.$(".result-hero")); k++) { const c = await p.$('#modal [data-r="1"]'); if (c) { await c.click(); await p.waitForTimeout(100); continue; } if (k % 7 === 0) await scan("mock-page"); await p.click("[data-next]"); await p.waitForTimeout(40); }
  await p.waitForTimeout(400); await scan("mock-result"); await p.screenshot({ path: out + "-mockres.png", fullPage: true }); } catch (e) { console.log("mock", e.message); }
console.log("errors:", errs.slice(0, 5));
console.log("leaks:", leaks.size); for (const [k, v] of leaks) console.log(`${v}\t${k}`);
await b.close();
